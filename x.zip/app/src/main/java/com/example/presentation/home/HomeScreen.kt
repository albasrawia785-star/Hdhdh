package com.example.presentation.home

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.ChatRequest
import com.example.domain.model.Conversation
import com.example.domain.model.DiscoveredDevice
import com.example.ui.theme.MessengerPrimary
import com.example.ui.theme.OfflineGray
import com.example.ui.theme.OnlineGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onNavigateToChat: (deviceId: String, deviceName: String, deviceIp: String) -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {

        val discoveredDevices by viewModel.discoveredDevices.collectAsStateWithLifecycle()
        val conversations by viewModel.conversations.collectAsStateWithLifecycle()
        val pendingRequests by viewModel.pendingRequests.collectAsStateWithLifecycle()
        val myDeviceName by viewModel.myDeviceName.collectAsStateWithLifecycle()
        val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
        val isProcessingRequest by viewModel.isProcessingRequest.collectAsStateWithLifecycle()

        // Smart Network Status Flow
        val wifiSsid by viewModel.wifiSsid.collectAsStateWithLifecycle()
        val localIp by viewModel.localIp.collectAsStateWithLifecycle()
        val isNetworkConnected by viewModel.isNetworkConnected.collectAsStateWithLifecycle()
        val lastDiscoveryPulse by viewModel.lastDiscoveryPulse.collectAsStateWithLifecycle()

        var selectedTab by remember { mutableIntStateOf(0) } // 0 = Devices, 1 = Chats
        var searchQuery by remember { mutableStateOf("") }
        var isNavigating by remember { mutableStateOf(false) }
        var showNetworkDetailsDialog by remember { mutableStateOf(false) }

        LaunchedEffect(Unit) {
            isNavigating = false
        }

        LaunchedEffect(toastMessage) {
            toastMessage?.let { msg ->
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                viewModel.clearToast()
            }
        }

        Scaffold(
            containerColor = Color(0xFFF8FAFC),
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        Brush.linearGradient(
                                            listOf(Color(0xFF2563EB), Color(0xFF1D4ED8))
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Wifi,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "واصل",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 20.sp,
                                    color = Color(0xFF0F172A)
                                )
                                Text(
                                    text = "جهازك: $myDeviceName",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.p2pManager.startEngine() }) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تحديث",
                                tint = Color(0xFF2563EB)
                            )
                        }
                        IconButton(onClick = onNavigateToSettings) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "الإعدادات",
                                tint = Color(0xFF334155)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = Color.White,
                    tonalElevation = 6.dp,
                    modifier = Modifier.border(
                        width = 1.dp,
                        color = Color(0xFFE2E8F0),
                        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
                    )
                ) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = {
                            val count = discoveredDevices.count { it.isOnline }
                            BadgedBox(
                                badge = {
                                    if (count > 0) {
                                        Badge(containerColor = Color(0xFF2563EB)) { Text("$count", color = Color.White) }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Devices, contentDescription = "الأجهزة المتاحة")
                            }
                        },
                        label = { Text("الأجهزة", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Medium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF2563EB),
                            selectedTextColor = Color(0xFF2563EB),
                            indicatorColor = Color(0xFF2563EB).copy(alpha = 0.12f)
                        )
                    )

                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = {
                            val totalUnread = conversations.sumOf { it.unreadCount }
                            BadgedBox(
                                badge = {
                                    if (totalUnread > 0) {
                                        Badge(containerColor = Color(0xFF2563EB)) { Text("$totalUnread", color = Color.White) }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.ChatBubble, contentDescription = "الدردشات")
                            }
                        },
                        label = { Text("الدردشات", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Medium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF2563EB),
                            selectedTextColor = Color(0xFF2563EB),
                            indicatorColor = Color(0xFF2563EB).copy(alpha = 0.12f)
                        )
                    )

                    NavigationBarItem(
                        selected = false,
                        onClick = onNavigateToSettings,
                        icon = {
                            Icon(Icons.Default.Settings, contentDescription = "الإعدادات")
                        },
                        label = { Text("الإعدادات", fontWeight = FontWeight.Medium) },
                        colors = NavigationBarItemDefaults.colors(
                            unselectedIconColor = Color(0xFF64748B),
                            unselectedTextColor = Color(0xFF64748B)
                        )
                    )
                }
            }
        ) { innerPadding ->

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {

                // Smart Network Status Bar (Real-Time Discovery Monitor)
                SmartNetworkStatusBar(
                    ssid = wifiSsid,
                    localIp = localIp,
                    isConnected = isNetworkConnected,
                    lastDiscoveryPulse = lastDiscoveryPulse,
                    deviceCount = discoveredDevices.count { it.isOnline },
                    onOpenDetails = { showNetworkDetailsDialog = true }
                )

                // Disconnection Warning Alert Banner with Auto-Retry notice
                AnimatedVisibility(
                    visible = !isNetworkConnected,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFFEF2F2))
                            .border(width = 1.dp, color = Color(0xFFFCA5A5))
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = Color(0xFFDC2626),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "تم فقد الاتصال بالشبكة، سيتم إعادة المحاولة تلقائياً",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF991B1B)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                ) {
                    if (selectedTab == 0) {
                        // Devices Tab
                        DevicesTabContent(
                            devices = discoveredDevices.filter { it.isOnline },
                            searchQuery = searchQuery,
                            onSearchQueryChange = { searchQuery = it },
                            onSendRequest = { viewModel.sendChatRequest(it) }
                        )
                    } else {
                        // Conversations Tab
                        ConversationsTabContent(
                            conversations = conversations,
                            searchQuery = searchQuery,
                            onSearchQueryChange = { searchQuery = it },
                            onConversationClick = { conv ->
                                if (!isNavigating) {
                                    isNavigating = true
                                    onNavigateToChat(conv.targetDeviceId, conv.targetDeviceName, conv.targetIpAddress)
                                }
                            }
                        )
                    }

                    // Chat Request Overlay Dialog
                    if (pendingRequests.isNotEmpty()) {
                        val request = pendingRequests.first()
                        ChatRequestDialog(
                            request = request,
                            isProcessing = isProcessingRequest,
                            onAccept = {
                                viewModel.respondToRequest(
                                    request = request,
                                    accept = true,
                                    onAccepted = { id, name, ip ->
                                        if (!isNavigating) {
                                            isNavigating = true
                                            onNavigateToChat(id, name, ip)
                                        }
                                    }
                                )
                            },
                            onDecline = {
                                viewModel.respondToRequest(request = request, accept = false)
                            }
                        )
                    }

                    if (showNetworkDetailsDialog) {
                        NetworkDiscoveryDetailsDialog(
                            ssid = wifiSsid,
                            localIp = localIp,
                            lastDiscoveryPulse = lastDiscoveryPulse,
                            onlineDevices = discoveredDevices.filter { it.isOnline },
                            onDismiss = { showNetworkDetailsDialog = false }
                        )
                    }
                }
            }
        }
    }
}

/**
 * Smart Network Status Bar Component with Real-time Discovery Monitor
 */
@Composable
fun SmartNetworkStatusBar(
    ssid: String,
    localIp: String,
    isConnected: Boolean,
    lastDiscoveryPulse: Long,
    deviceCount: Int,
    onOpenDetails: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulseTransition")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isConnected) Color(0xFFF0F9FF) else Color(0xFFFEF2F2)
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isConnected) Color(0xFFBAE6FD) else Color(0xFFFECACA)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(if (isConnected) Color(0xFFE0F2FE) else Color(0xFFFEE2E2)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isConnected) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF0284C7).copy(alpha = pulseAlpha * 0.25f))
                            )
                        }
                        Icon(
                            imageVector = if (isConnected) Icons.Default.Radar else Icons.Default.WifiOff,
                            contentDescription = null,
                            tint = if (isConnected) Color(0xFF0284C7) else Color(0xFFDC2626),
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (ssid.isNotBlank()) "نقطة الاتصال: $ssid" else "نقطة الاتصال الشخصية (Hotspot)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = if (isConnected) Color(0xFF0369A1) else Color(0xFF991B1B)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (localIp.isNotBlank()) "IP: $localIp (النطاق المحلي)" else "IP: غير معرف",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                // Interactive Network Status Pill
                Surface(
                    onClick = onOpenDetails,
                    shape = RoundedCornerShape(20.dp),
                    color = if (isConnected) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isConnected) Color(0xFF86EFAC) else Color(0xFFFCA5A5))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isConnected) Color(0xFF16A34A).copy(alpha = pulseAlpha) else Color(0xFFDC2626))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isConnected) "P2P: نشط" else "غير متصل",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isConnected) Color(0xFF15803D) else Color(0xFF991B1B)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "التفاصيل",
                            tint = if (isConnected) Color(0xFF15803D) else Color(0xFF991B1B),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(if (isConnected) Color(0xFFE0F2FE) else Color(0xFFFEE2E2))
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Devices,
                        contentDescription = null,
                        tint = Color(0xFF0284C7),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "المسح المباشر في نطاق Hotspot (UDP P2P):",
                        fontSize = 11.sp,
                        color = Color(0xFF334155),
                        fontWeight = FontWeight.Medium
                    )
                }

                Text(
                    text = if (deviceCount > 0) "$deviceCount أجهزة أونلاين" else "جاري الفحص المباشر...",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (deviceCount > 0) Color(0xFF16A34A) else Color(0xFF0284C7)
                )
            }
        }
    }
}

@Composable
fun NetworkDiscoveryDetailsDialog(
    ssid: String,
    localIp: String,
    lastDiscoveryPulse: Long,
    onlineDevices: List<DiscoveredDevice>,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(24.dp)),
            color = Color.White,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFE0F2FE)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Radar,
                                contentDescription = null,
                                tint = Color(0xFF0284C7),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "مراقب استكشاف الشبكة P2P",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "بروتوكول المسح المباشر عبر نقطة الاتصال",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Diagnostic Stats Grid
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFFF8FAFC))
                        .border(1.dp, Color(0xFFE2E8F0))
                        .padding(12.dp)
                ) {
                    DiagnosticRow(
                        title = "بروتوكول الاكتشاف",
                        value = "UDP Direct Broadcast",
                        highlight = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    DiagnosticRow(
                        title = "منافذ الاتصال المحلية",
                        value = "TCP 8889 / UDP 8888",
                        highlight = false
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    DiagnosticRow(
                        title = "نطاق الشبكة الحالية",
                        value = if (ssid.isNotBlank()) ssid else "Wi-Fi LAN",
                        highlight = false
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    DiagnosticRow(
                        title = "عنوان جهازك المحلي",
                        value = if (localIp.isNotBlank()) localIp else "غير معرف",
                        highlight = false
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    DiagnosticRow(
                        title = "حالة استكشاف P2P",
                        value = "نشط ويبحث تلقائياً",
                        highlight = true
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "الأجهزة المكتشفة أونلاين (${onlineDevices.size}):",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color(0xFF334155)
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (onlineDevices.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "جاري البحث المباشر عن الأجهزة المتصلة بنقطة الاتصال...",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B),
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    ) {
                        items(onlineDevices, key = { it.deviceId }) { dev ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFFF0FDF4))
                                    .border(1.dp, Color(0xFFBBF7D0))
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = dev.deviceName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color(0xFF166534)
                                    )
                                    Text(
                                        text = "IP: ${dev.ipAddress} • المنفذ: ${dev.port}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF15803D)
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF16A34A))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("أونلاين", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                ) {
                    Text("حسناً، فهمت", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}

@Composable
private fun DiagnosticRow(
    title: String,
    value: String,
    highlight: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, fontSize = 12.sp, color = Color(0xFF64748B))
        Text(
            value,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (highlight) Color(0xFF16A34A) else Color(0xFF1E293B)
        )
    }
}

@Composable
fun DevicesTabContent(
    devices: List<DiscoveredDevice>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onSendRequest: (DiscoveredDevice) -> Unit
) {
    val filtered = devices.filter {
        it.deviceName.contains(searchQuery, ignoreCase = true) ||
                it.ipAddress.contains(searchQuery)
    }

    Column(modifier = Modifier.fillMaxSize()) {

        // Search Input Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = { Text("بحث عن جهاز...", color = Color(0xFF94A3B8), fontSize = 14.sp) },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null, tint = Color(0xFF64748B)) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Color.Transparent,
                focusedBorderColor = MessengerPrimary,
                unfocusedContainerColor = Color(0xFFF1F5F9),
                focusedContainerColor = Color.White
            ),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(MessengerPrimary.copy(alpha = 0.08f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Devices,
                            contentDescription = null,
                            tint = MessengerPrimary,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "لم يتم العثور على أجهزة متصلة قريبة",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937),
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "افتح تطبيق واصل على الجهاز الآخر وتأكد من الاتصال بنقطة الاتصال الشخصية (Hotspot)",
                        color = Color(0xFF64748B),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 20.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                items(filtered, key = { it.deviceId }) { device ->
                    DeviceRowItem(
                        device = device,
                        onSendRequest = { onSendRequest(device) }
                    )
                }
            }
        }
    }
}

@Composable
fun DeviceRowItem(
    device: DiscoveredDevice,
    onSendRequest: () -> Unit,
    onStartVoiceCall: (() -> Unit)? = null,
    onStartVideoCall: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF2563EB), Color(0xFF3B82F6))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        val avatarBitmap = remember(device.avatarBase64) {
                            if (device.avatarBase64.isNotBlank()) {
                                try {
                                    val bytes = android.util.Base64.decode(device.avatarBase64, android.util.Base64.DEFAULT)
                                    android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                } catch (e: Exception) { null }
                            } else null
                        }

                        if (avatarBitmap != null) {
                            Image(
                                bitmap = avatarBitmap.asImageBitmap(),
                                contentDescription = "صورة الجهاز المكتشف",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize().clip(CircleShape)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = device.deviceName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color(0xFF0F172A)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (device.isOnline) OnlineGreen else OfflineGray)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (device.isOnline) "أونلاين • IP: ${device.ipAddress}" else "غير متصل • IP: ${device.ipAddress}",
                                fontSize = 12.sp,
                                color = if (device.isOnline) Color(0xFF15803D) else Color(0xFF64748B)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (device.isOnline) Color(0xFFDCFCE7) else Color(0xFFF1F5F9))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (device.isOnline) "أونلاين" else "غير متصل",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (device.isOnline) Color(0xFF166534) else Color(0xFF64748B)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onSendRequest,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MessengerPrimary)
                ) {
                    Text("مراسلة", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                if (onStartVideoCall != null) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF00A884).copy(alpha = 0.12f))
                            .clickable { onStartVideoCall() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = "اتصال فيديو",
                            tint = Color(0xFF00A884),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                if (onStartVoiceCall != null) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF00A884).copy(alpha = 0.12f))
                            .clickable { onStartVoiceCall() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "اتصال صوتي",
                            tint = Color(0xFF00A884),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ConversationsTabContent(
    conversations: List<Conversation>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onConversationClick: (Conversation) -> Unit
) {
    val filtered = conversations.filter {
        it.targetDeviceName.contains(searchQuery, ignoreCase = true) ||
                it.lastMessage.contains(searchQuery, ignoreCase = true)
    }

    Column(modifier = Modifier.fillMaxSize()) {

        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = { Text("بحث في المحادثات...", color = Color(0xFF94A3B8), fontSize = 14.sp) },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null, tint = Color(0xFF64748B)) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Color.Transparent,
                focusedBorderColor = MessengerPrimary,
                unfocusedContainerColor = Color(0xFFF1F5F9),
                focusedContainerColor = Color.White
            ),
            singleLine = true
        )

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "لا توجد محادثات قائمة حالياً",
                    color = Color(0xFF64748B),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                items(filtered, key = { it.targetDeviceId }) { conv ->
                    ConversationRowItem(
                        conversation = conv,
                        onClick = { onConversationClick(conv) }
                    )
                }
            }
        }
    }
}

@Composable
fun ConversationRowItem(
    conversation: Conversation,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        color = Color.White
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Sender Avatar Box
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFEFF6FF)),
                contentAlignment = Alignment.Center
            ) {
                val avatarBitmap = remember(conversation.avatarBase64) {
                    if (conversation.avatarBase64.isNotBlank()) {
                        try {
                            val bytes = android.util.Base64.decode(conversation.avatarBase64, android.util.Base64.DEFAULT)
                            android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        } catch (e: Exception) {
                            null
                        }
                    } else null
                }

                if (avatarBitmap != null) {
                    Image(
                        bitmap = avatarBitmap.asImageBitmap(),
                        contentDescription = "صورة ${conversation.targetDeviceName}",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().clip(CircleShape)
                    )
                } else {
                    val initial = conversation.targetDeviceName.trim().take(1).uppercase()
                    if (initial.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Brush.linearGradient(listOf(MessengerPrimary, Color(0xFF1D4ED8)))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = initial,
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = Color.White
                            )
                        }
                    } else {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = Color(0xFF2563EB),
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                // Online/Offline Status Indicator
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(if (conversation.isOnline) OnlineGreen else OfflineGray)
                        .border(2.dp, Color.White, CircleShape)
                        .align(Alignment.BottomEnd)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = conversation.targetDeviceName.ifBlank { "مستخدم محلي" },
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color(0xFF0F172A),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = formatTimestamp(conversation.lastMessageTimestamp),
                        fontSize = 12.sp,
                        color = if (conversation.unreadCount > 0) MessengerPrimary else Color(0xFF94A3B8),
                        fontWeight = if (conversation.unreadCount > 0) FontWeight.Bold else FontWeight.Normal
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = conversation.lastMessage.ifBlank { "انقر للبدء بالمحادثة" },
                        fontSize = 14.sp,
                        color = if (conversation.unreadCount > 0) Color(0xFF0F172A) else Color(0xFF64748B),
                        fontWeight = if (conversation.unreadCount > 0) FontWeight.SemiBold else FontWeight.Normal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    if (conversation.unreadCount > 0) {
                        Box(
                            modifier = Modifier
                                .padding(start = 8.dp)
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(MessengerPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${conversation.unreadCount}",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatRequestDialog(
    request: ChatRequest,
    isProcessing: Boolean,
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    Dialog(
        onDismissRequest = { if (!isProcessing) onDecline() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White),
            color = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDecline) {
                        Icon(
                            imageVector = Icons.Default.ChevronLeft,
                            contentDescription = "رجوع",
                            tint = Color(0xFF1F2937),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "طلب مراسلة وارد",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color(0xFF1F2937)
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(110.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFEFF6FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Group,
                            contentDescription = null,
                            tint = MessengerPrimary,
                            modifier = Modifier.size(56.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    Text(
                        text = "يريد جهاز",
                        fontSize = 16.sp,
                        color = Color(0xFF64748B)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = request.senderName,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 26.sp,
                        color = Color(0xFF1F2937)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "بدء محادثة معك عبر الشبكة المحلية",
                        fontSize = 14.sp,
                        color = Color(0xFF64748B)
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp)
                ) {
                    Button(
                        onClick = onAccept,
                        enabled = !isProcessing,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MessengerPrimary)
                    ) {
                        if (isProcessing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("قبول البدء", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = onDecline,
                        enabled = !isProcessing,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, MessengerPrimary),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MessengerPrimary)
                    ) {
                        Text("رفض", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private fun formatTimestamp(timestamp: Long): String {
    val date = Date(timestamp)
    val sdf = SimpleDateFormat("hh:mm a", Locale("ar"))
    return sdf.format(date)
}
