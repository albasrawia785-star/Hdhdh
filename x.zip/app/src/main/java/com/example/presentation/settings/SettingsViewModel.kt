package com.example.presentation.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.db.AppDatabase
import com.example.data.local.preferences.UserPreferences
import com.example.data.local.storage.FileManager
import com.example.data.network.P2PNetworkManager
import com.example.util.NetworkUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val userPrefs = UserPreferences(application)
    private val fileManager = FileManager(application)
    private val p2pManager = P2PNetworkManager.getInstance(application)

    val deviceName: StateFlow<String> = userPrefs.deviceName
    val deviceId: String = userPrefs.deviceId
    val userAvatarPath: StateFlow<String> = userPrefs.avatarPath

    private val _ipAddress = MutableStateFlow(NetworkUtils.getLocalIpAddress())
    val ipAddress: StateFlow<String> = _ipAddress

    val gatewayIp: String
        get() = NetworkUtils.getGatewayIpAddress(getApplication())

    val udpPort: Int = 8888
    val tcpPort: Int = 8889

    val isUdpActive: Boolean
        get() = p2pManager.isUdpActive

    val isTcpActive: Boolean
        get() = p2pManager.isTcpActive

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    init {
        userPrefs.setConnectionMode(UserPreferences.MODE_HOTSPOT)
    }

    fun refreshNetworkInfo() {
        _ipAddress.value = NetworkUtils.getLocalIpAddress()
    }

    fun saveDeviceName(newName: String) {
        userPrefs.setDeviceName(newName)
        p2pManager.broadcastPresenceNow()
        _message.value = "تم تحديث اسم الجهاز بنجاح وتعميمه على الشبكة"
    }

    fun saveUserAvatar(uri: android.net.Uri) {
        viewModelScope.launch {
            val localPath = fileManager.copyUriToInternalStorage(uri, "user_avatar.jpg")
            if (localPath != null) {
                userPrefs.setUserAvatarPath(localPath)
                p2pManager.broadcastPresenceNow()
                _message.value = "تم تحديث الصورة الشخصية بنجاح وتعميمها على الشبكة"
            } else {
                _message.value = "فشل تحديث الصورة الشخصية"
            }
        }
    }

    fun clearAllChats() {
        viewModelScope.launch {
            db.conversationDao().deleteAllConversations()
            db.messageDao().deleteAllMessages()
            db.chatRequestDao().deleteAllRequests()
            _message.value = "تم مسح جميع سجلات المحادثات بنجاح"
        }
    }

    fun clearReceivedFiles() {
        viewModelScope.launch {
            val count = fileManager.clearCache()
            _message.value = "تم تنظيف $count ملفات مؤقتة ومستلمة"
        }
    }

    fun clearMessage() {
        _message.value = null
    }
}
