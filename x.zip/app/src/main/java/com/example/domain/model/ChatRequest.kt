package com.example.domain.model

enum class RequestStatus {
    PENDING,
    ACCEPTED,
    DECLINED
}

/**
 * Domain model for a Chat Request between devices.
 */
data class ChatRequest(
    val requestId: String,
    val senderDeviceId: String,
    val senderName: String,
    val senderIp: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: RequestStatus = RequestStatus.PENDING
)
