package com.example.presentation.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderDelete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.MessengerPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onBackClick: () -> Unit,
    onNavigateToErrorLogs: () -> Unit = {}
) {
    val context = LocalContext.current

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {

        val currentDeviceName by viewModel.deviceName.collectAsStateWithLifecycle()
        val ipAddress by viewModel.ipAddress.collectAsStateWithLifecycle()
        val message by viewModel.message.collectAsStateWithLifecycle()
        val userAvatarPath by viewModel.userAvatarPath.collectAsStateWithLifecycle()

        val avatarPickerLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri: Uri? ->
            uri?.let { viewModel.saveUserAvatar(it) }
        }

        var nameInput by remember { mutableStateOf(currentDeviceName) }
        var isEditingName by remember { mutableStateOf(false) }
        var showClearDialog by remember { mutableStateOf(false) }
        var showClearFilesDialog by remember { mutableStateOf(false) }
        var showAboutDialog by remember { mutableStateOf(false) }
        var showDiagnosticsDialog by remember { mutableStateOf(false) }

        LaunchedEffect(currentDeviceName) {
            nameInput = currentDeviceName
        }

        LaunchedEffect(Unit) {
            viewModel.refreshNetworkInfo()
        }

        LaunchedEffect(message) {
            message?.let {
                Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
                viewModel.clearMessage()
            }
        }

        Scaffold(
            containerColor = Color(0xFFF1F5F9),
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "الإعدادات",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = Color(0xFF0F172A)
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBackClick) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع",
                                tint = Color(0xFF0F172A)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            }
        ) { innerPadding ->

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                // ================= Group 1: Profile & Identity =================
                CardGroup(title = "الملف الشخصي والجهاز") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Avatar Box
                            Box(
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(CircleShape)
                                    .clickable { avatarPickerLauncher.launch("image/*") }
                                    .background(
                                        Brush.linearGradient(
                                            listOf(Color(0xFF2563EB), Color(0xFF3B82F6))
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                val avatarBitmap = remember(userAvatarPath) {
                                    if (userAvatarPath.isNotBlank() && java.io.File(userAvatarPath).exists()) {
                                        try {
                                            android.graphics.BitmapFactory.decodeFile(userAvatarPath)
                                        } catch (e: Exception) { null }
                                    } else null
                                }

                                if (avatarBitmap != null) {
                                    Image(
                                        bitmap = avatarBitmap.asImageBitmap(),
                                        contentDescription = "الصورة الشخصية",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize().clip(CircleShape)
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(Color.White)
                                        .padding(2.dp)
                                        .clip(CircleShape)
                                        .background(MessengerPrimary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PhotoCamera,
                                        contentDescription = "تغيير الصورة",
                                        tint = Color.White,
                                        modifier = Modifier.size(11.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "اسم العرض في المحادثات",
                                    fontSize = 12.sp,
                                    color = Color(0xFF64748B),
                                    fontWeight = FontWeight.Medium
                                )

                                Spacer(modifier = Modifier.height(2.dp))

                                if (isEditingName) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        OutlinedTextField(
                                            value = nameInput,
                                            onValueChange = { nameInput = it },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(12.dp),
                                            singleLine = true,
                                            placeholder = { Text("أدخل الاسم الجديد") },
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedBorderColor = MessengerPrimary,
                                                unfocusedBorderColor = Color(0xFFCBD5E1)
                                            )
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        IconButton(
                                            onClick = {
                                                if (nameInput.isNotBlank()) {
                                                    viewModel.saveDeviceName(nameInput)
                                                }
                                                isEditingName = false
                                            }
                                        ) {
                                            Icon(Icons.Default.Save, contentDescription = "حفظ", tint = MessengerPrimary)
                                        }
                                        IconButton(
                                            onClick = {
                                                nameInput = currentDeviceName
                                                isEditingName = false
                                            }
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = "إلغاء", tint = Color(0xFF94A3B8))
                                        }
                                    }
                                } else {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = nameInput,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 17.sp,
                                            color = Color(0xFF0F172A)
                                        )

                                        IconButton(onClick = { isEditingName = true }) {
                                            Icon(
                                                imageVector = Icons.Default.Edit,
                                                contentDescription = "تعديل",
                                                tint = Color(0xFF2563EB)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFF1F5F9)))
                        Spacer(modifier = Modifier.height(12.dp))

                        // Copy Device ID row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("معرف الحساب المحلي", fontSize = 11.sp, color = Color(0xFF94A3B8))
                                Text(
                                    text = viewModel.deviceId.take(18) + "...",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF475569)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = Color(0xFFEFF6FF),
                                modifier = Modifier.clickable {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Device ID", viewModel.deviceId))
                                    Toast.makeText(context, "تم نسخ معرف الحساب", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("نسخ المعرف", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2563EB))
                                }
                            }
                        }
                    }
                }

                // ================= Group 2: Network & Connection =================
                CardGroup(title = "شبكة نقطة الاتصال (Hotspot)") {
                    Column {
                        // Connection Status Row
                        SettingsItemRow(
                            icon = Icons.Default.Wifi,
                            iconBgColor = if (ipAddress.isNotEmpty()) Color(0xFFDCFCE7) else Color(0xFFF1F5F9),
                            iconTint = if (ipAddress.isNotEmpty()) Color(0xFF16A34A) else Color(0xFF64748B),
                            title = "حالة اتصال Hotspot",
                            subtitle = if (ipAddress.isNotEmpty()) "متصل بنقطة الاتصال المحلية (IP: $ipAddress)" else "غير متصل بنقطة الاتصال (Hotspot)",
                            trailingContent = {
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(if (ipAddress.isNotEmpty()) Color(0xFF22C55E) else Color(0xFF94A3B8))
                                        .size(10.dp)
                                )
                            }
                        )

                        ItemDivider()

                        // Refresh Network
                        SettingsItemRow(
                            icon = Icons.Default.Refresh,
                            iconBgColor = Color(0xFFEFF6FF),
                            iconTint = Color(0xFF2563EB),
                            title = "إعادة فحص وتحديث الشبكة",
                            subtitle = "تحديث العنوان واكتشاف الأجهزة القريبة فوراً",
                            onClick = {
                                viewModel.refreshNetworkInfo()
                                Toast.makeText(context, "تمت إعادة فحص الشبكة المحلية", Toast.LENGTH_SHORT).show()
                            }
                        )

                        ItemDivider()

                        // Wi-Fi Settings Intent Shortcut
                        SettingsItemRow(
                            icon = Icons.Default.Settings,
                            iconBgColor = Color(0xFFF3E8FF),
                            iconTint = Color(0xFF9333EA),
                            title = "إعدادات Wi-Fi للجهاز",
                            subtitle = "فتح إعدادات الشبكة اللاسلكية في النظام",
                            onClick = {
                                try {
                                    context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                                } catch (e: Exception) {
                                    Toast.makeText(context, "تعذر فتح إعدادات Wi-Fi", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )
                    }
                }

                // ================= Group 3: Data & Storage =================
                CardGroup(title = "البيانات والتخزين") {
                    Column {
                        SettingsItemRow(
                            icon = Icons.Default.FolderDelete,
                            iconBgColor = Color(0xFFFEF3C7),
                            iconTint = Color(0xFFD97706),
                            title = "تنظيف الذاكرة المؤقتة",
                            subtitle = "مسح الصور والملفات المؤقتة لتوفير المساحة",
                            onClick = { showClearFilesDialog = true }
                        )

                        ItemDivider()

                        SettingsItemRow(
                            icon = Icons.Default.DeleteSweep,
                            iconBgColor = Color(0xFFFEE2E2),
                            iconTint = Color(0xFFDC2626),
                            title = "مسح جميع سجلات المحادثات",
                            subtitle = "حذف كافة الرسائل السابقة المخزنة محلياً",
                            onClick = { showClearDialog = true }
                        )
                    }
                }

                // ================= Group 4: Support & About =================
                CardGroup(title = "الدعم والمساعدة") {
                    Column {
                        // WhatsApp Direct Support
                        SettingsItemRow(
                            icon = Icons.AutoMirrored.Filled.Chat,
                            iconBgColor = Color(0xFFDCFCE7),
                            iconTint = Color(0xFF16A34A),
                            title = "تواصل مع الدعم الفني",
                            subtitle = "محادثة مباشرة عبر تطبيق الواتساب",
                            onClick = {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/9647810836783"))
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "تعذر فتح تطبيق الواتساب", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )

                        ItemDivider()

                        // About App
                        SettingsItemRow(
                            icon = Icons.Default.Info,
                            iconBgColor = Color(0xFFE0F2FE),
                            iconTint = Color(0xFF0284C7),
                            title = "عن تطبيق واصل",
                            subtitle = "تطبيق مراسلة محلية آمنة 100% عبر نقطة الاتصال الشخصية (Hotspot) بدون إنترنت",
                            onClick = { showAboutDialog = true }
                        )
                    }
                }

                // ================= Group 5: Advanced & Technical (Optional) =================
                CardGroup(title = "خيارات متقدمة للمطورين") {
                    Column {
                        SettingsItemRow(
                            icon = Icons.Default.NetworkCheck,
                            iconBgColor = Color(0xFFF1F5F9),
                            iconTint = Color(0xFF475569),
                            title = "فحص ومعلومات الشبكة المتقدمة",
                            subtitle = "عرض تفاصيل المنافذ وعناوين IP الفرعية",
                            onClick = { showDiagnosticsDialog = true }
                        )

                        ItemDivider()

                        SettingsItemRow(
                            icon = Icons.Default.BugReport,
                            iconBgColor = Color(0xFFF1F5F9),
                            iconTint = Color(0xFF64748B),
                            title = "سجل الأخطاء والعمليات",
                            subtitle = "استعراض تقارير النظام والأحداث الفنية",
                            onClick = onNavigateToErrorLogs
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Footer
                Text(
                    text = "تطبيق واصل • الإصدار 1.0.0 Pro\nاتصال آمن ومستقل محلياً 100%",
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Dialog: About App
            if (showAboutDialog) {
                AlertDialog(
                    onDismissRequest = { showAboutDialog = false },
                    containerColor = Color.White,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF0284C7))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("عن تطبيق واصل", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                    },
                    text = {
                        Column {
                            Text(
                                text = "تطبيق واصل هو منصة مراسلة فورية محلية تعمل بالكامل عبر نقطة الاتصال الشخصية (Hotspot) دون الحاجة لاتصال بالإنترنت أو خوادم خارجية.",
                                fontSize = 14.sp,
                                color = Color(0xFF334155),
                                lineHeight = 22.sp
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "• سرعة عالية في نقل الرسائل والملفات والصور.\n• حماية وخصوصية تامة للبيانات.\n• دعم إشعارات الاتصالات الصوتية والمحادثات المباشرة.",
                                fontSize = 13.sp,
                                color = Color(0xFF64748B),
                                lineHeight = 20.sp
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = { showAboutDialog = false },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MessengerPrimary)
                        ) {
                            Text("فهمت ذلك", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }

            // Dialog: Advanced Diagnostics
            if (showDiagnosticsDialog) {
                AlertDialog(
                    onDismissRequest = { showDiagnosticsDialog = false },
                    containerColor = Color.White,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.NetworkCheck, contentDescription = null, tint = Color(0xFF2563EB))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("معلومات الشبكة المتقدمة", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        }
                    },
                    text = {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            DiagnosticItem("عنوان IP المحلي", if (ipAddress.isNotEmpty()) ipAddress else "غير متصل")
                            DiagnosticItem("عنوان البوابة (Gateway)", viewModel.gatewayIp)
                            DiagnosticItem("منفذ الاكتشاف المفتوح", "${viewModel.udpPort}")
                            DiagnosticItem("منفذ البيانات المفتوح", "${viewModel.tcpPort}")
                            DiagnosticItem("حالة خدمة الاكتشاف", if (viewModel.isUdpActive) "نشط ومستمع" else "متوقف")
                            DiagnosticItem("حالة خادم الرسائل المحلي", if (viewModel.isTcpActive) "نشط ومستمع" else "متوقف")
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = { showDiagnosticsDialog = false },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MessengerPrimary)
                        ) {
                            Text("إغلاق", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }

            // Dialog: Clear Chats
            if (showClearDialog) {
                AlertDialog(
                    onDismissRequest = { showClearDialog = false },
                    containerColor = Color.White,
                    title = { Text("مسح جميع المحادثات", fontWeight = FontWeight.Bold) },
                    text = { Text("هل أنت متأكد من حذف كافة سجلات المحادثات والرسائل؟ لا يمكن التراجع عن هذا الإجراء.") },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.clearAllChats()
                                showClearDialog = false
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                        ) {
                            Text("حذف النهائي", fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showClearDialog = false }) {
                            Text("إلغاء", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }

            // Dialog: Clear Files Cache
            if (showClearFilesDialog) {
                AlertDialog(
                    onDismissRequest = { showClearFilesDialog = false },
                    containerColor = Color.White,
                    title = { Text("تنظيف الذاكرة المؤقتة", fontWeight = FontWeight.Bold) },
                    text = { Text("سيتم مسح الصور والملفات المؤقتة المخزنة لتوفير المساحة.") },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.clearReceivedFiles()
                                showClearFilesDialog = false
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
                        ) {
                            Text("تنظيف الآن", fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showClearFilesDialog = false }) {
                            Text("إلغاء", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun CardGroup(
    title: String,
    content: @Composable () -> Unit
) {
    Column {
        Text(
            text = title,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF64748B),
            modifier = Modifier.padding(start = 6.dp, bottom = 6.dp)
        )
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            content()
        }
    }
}

@Composable
fun SettingsItemRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBgColor: Color,
    iconTint: Color,
    title: String,
    subtitle: String,
    onClick: (() -> Unit)? = null,
    trailingContent: (@Composable () -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconBgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color(0xFF0F172A)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }
        }

        if (trailingContent != null) {
            trailingContent()
        } else if (onClick != null) {
            Icon(
                imageVector = Icons.Default.ChevronLeft,
                contentDescription = null,
                tint = Color(0xFF94A3B8),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun ItemDivider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(Color(0xFFF1F5F9))
            .padding(horizontal = 16.dp)
    )
}

@Composable
fun DiagnosticItem(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 12.sp, color = Color(0xFF64748B))
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
    }
}
