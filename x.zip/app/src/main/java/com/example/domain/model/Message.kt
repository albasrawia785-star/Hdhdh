package com.example.domain.model

enum class MessageType {
    TEXT,
    IMAGE,
    AUDIO,
    FILE
}

enum class MessageStatus {
    SENDING,
    SENT,       // ✓
    DELIVERED,  // ✓✓
    READ
}

/**
 * Domain model for a Chat Message.
 */
data class Message(
    val id: String,
    val conversationId: String,
    val senderDeviceId: String,
    val senderName: String,
    val isFromMe: Boolean,
    val type: MessageType,
    val textContent: String = "",
    val filePath: String? = null,
    val fileName: String? = null,
    val fileSize: Long = 0L,
    val audioDurationMs: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val status: MessageStatus = MessageStatus.SENT
)
