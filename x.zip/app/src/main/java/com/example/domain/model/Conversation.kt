package com.example.domain.model

/**
 * Domain model for a P2P Chat Conversation.
 */
data class Conversation(
    val id: String, // Target device ID
    val targetDeviceId: String,
    val targetDeviceName: String,
    val targetIpAddress: String,
    val lastMessage: String = "",
    val lastMessageTimestamp: Long = System.currentTimeMillis(),
    val unreadCount: Int = 0,
    val isAccepted: Boolean = false,
    val isOnline: Boolean = true,
    val avatarBase64: String = ""
)
