package com.example.data.network

import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity

class P2PForegroundService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    companion object {
        private const val TAG = "P2PForegroundService"
        private const val CHANNEL_ID = "wasel_p2p_service_channel"
        private const val NOTIFICATION_ID = 1001

        fun startService(context: Context) {
            try {
                val intent = Intent(context, P2PForegroundService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error starting P2PForegroundService safely", e)
            }
        }

        fun stopService(context: Context) {
            try {
                val intent = Intent(context, P2PForegroundService::class.java)
                context.stopService(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping P2PForegroundService safely", e)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Creating P2P Foreground Service...")
        createNotificationChannel()

        // Start P2P Engine
        P2PNetworkManager.getInstance(applicationContext).startEngine()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.i(TAG, "Starting P2P Foreground Service...")

        val notificationIntent = Intent(this, MainActivity::class.java).apply {
            setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            notificationIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("واصل - MESH P2P")
            .setContentText("محرك الشبكة المحلية نشط وجاهز لاستقبال الرسائل في الخلفية")
            .setSmallIcon(android.R.drawable.ic_menu_send)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
                    )
                } catch (e: Throwable) {
                    Log.w(TAG, "startForeground with type connectedDevice failed, falling back to basic foreground", e)
                    startForeground(NOTIFICATION_ID, notification)
                }
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Error starting foreground notification", e)
        }

        // Acquire locks AFTER foreground service registration for AppOps approval
        acquireLocks()

        return START_STICKY
    }

    private fun acquireLocks() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
            if (wakeLock == null) {
                wakeLock = powerManager?.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "WasilP2P::PartialWakeLock"
                )
            }
            wakeLock?.let { lock ->
                try {
                    lock.setReferenceCounted(false)
                    if (!lock.isHeld) {
                        lock.acquire(60 * 60 * 1000L /* 60 mins safe timeout */)
                    }
                } catch (e: Throwable) {
                    Log.w(TAG, "Failed to acquire wake lock safely", e)
                }
            }

            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            if (wifiLock == null && wifiManager != null) {
                val wifiMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                } else {
                    @Suppress("DEPRECATION")
                    WifiManager.WIFI_MODE_FULL_HIGH_PERF
                }
                wifiLock = wifiManager.createWifiLock(
                    wifiMode,
                    "WasilP2P::WifiLock"
                )
            }
            wifiLock?.let { lock ->
                try {
                    if (!lock.isHeld) {
                        lock.acquire()
                    }
                } catch (e: Throwable) {
                    Log.w(TAG, "Failed to acquire wifi lock safely", e)
                }
            }

            if (multicastLock == null && wifiManager != null) {
                multicastLock = wifiManager.createMulticastLock("WasilP2P::MulticastLock")
            }
            multicastLock?.let { lock ->
                try {
                    if (!lock.isHeld) {
                        lock.acquire()
                    }
                } catch (e: Throwable) {
                    Log.w(TAG, "Failed to acquire multicast lock safely", e)
                }
            }
            Log.i(TAG, "Acquired WakeLock, WifiLock, and MulticastLock successfully")
        } catch (e: Throwable) {
            Log.e(TAG, "Error acquiring locks", e)
        }
    }

    private fun releaseLocks() {
        try {
            wakeLock?.let { lock ->
                try {
                    if (lock.isHeld) {
                        lock.release()
                    }
                } catch (e: Throwable) {
                    Log.w(TAG, "Safe release WakeLock exception ignored", e)
                }
            }
            wifiLock?.let { lock ->
                try {
                    if (lock.isHeld) {
                        lock.release()
                    }
                } catch (e: Throwable) {
                    Log.w(TAG, "Safe release WifiLock exception ignored", e)
                }
            }
            multicastLock?.let { lock ->
                try {
                    if (lock.isHeld) {
                        lock.release()
                    }
                } catch (e: Throwable) {
                    Log.w(TAG, "Safe release MulticastLock exception ignored", e)
                }
            }
            Log.i(TAG, "Released WakeLock, WifiLock, and MulticastLock")
        } catch (e: Throwable) {
            Log.e(TAG, "Error releasing locks", e)
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        Log.i(TAG, "App task removed, maintaining P2P Foreground Service...")
        try {
            // Service is already running as a Foreground Service with START_STICKY.
            // On Android 12+ (API 31+), calling startForegroundService inside onTaskRemoved causes
            // ForegroundServiceStartNotAllowedException which crashes/kills the service.
            // We refresh the P2P engine state to ensure UDP/TCP sockets stay bound.
            P2PNetworkManager.getInstance(applicationContext).startEngine()
        } catch (e: Throwable) {
            Log.e(TAG, "Error in onTaskRemoved", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "خدمة الشبكة المحلية - واصل",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إبقاء التطبيق متصلاً بالشبكة المحلية لاستقبال الرسائل في الخلفية"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        Log.i(TAG, "Destroying P2P Foreground Service...")
        releaseLocks()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
