package com.example.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "error_logs")
data class ErrorLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val dateTimeFormatted: String,
    val screenName: String = "",
    val fileName: String = "",
    val functionName: String = "",
    val lineNumber: Int = -1,
    val errorType: String = "CRITICAL", // CRITICAL, WARNING, INFO
    val errorMessage: String = "",
    val stackTrace: String = "",
    val appVersion: String = "1.0.0",
    val androidVersion: String = "",
    val deviceName: String = "",
    val deviceModel: String = "",
    val ipAddress: String = "",
    val connectionStatus: String = "",
    val isHost: Boolean = false
)
