package com.example.presentation.chat

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.compose.runtime.DisposableEffect
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.network.CallInfo
import com.example.data.network.CallState
import com.example.domain.model.Message
import com.example.domain.model.MessageStatus
import com.example.domain.model.MessageType
import com.example.ui.theme.OfflineGray
import com.example.ui.theme.OnlineGreen
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    targetDeviceId: String,
    targetDeviceName: String,
    targetIp: String,
    viewModel: ChatViewModel,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current

    LaunchedEffect(targetDeviceId, targetDeviceName, targetIp) {
        viewModel.init(targetDeviceId, targetDeviceName, targetIp)
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {

        val messages by viewModel.messages.collectAsStateWithLifecycle()
        val isPeerOnline by viewModel.isPeerOnline.collectAsStateWithLifecycle()
        val isPeerTyping by viewModel.isPeerTyping.collectAsStateWithLifecycle()
        val isRecordingAudio by viewModel.isRecordingAudio.collectAsStateWithLifecycle()
        val recordingDurationSeconds by viewModel.recordingDurationSeconds.collectAsStateWithLifecycle()
        val audioState by viewModel.audioPlaybackState.collectAsStateWithLifecycle()
        val callInfo by viewModel.callInfo.collectAsStateWithLifecycle()
        val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()

        var inputText by remember { mutableStateOf("") }
        var showAttachmentMenu by remember { mutableStateOf(false) }
        val listState = rememberLazyListState()
        val imeBottom = WindowInsets.ime.asPaddingValues().calculateBottomPadding()

        DisposableEffect(targetDeviceId) {
            viewModel.setActiveChat()
            onDispose {
                viewModel.clearActiveChat()
            }
        }

        LaunchedEffect(toastMessage) {
            toastMessage?.let {
                Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
                viewModel.clearToast()
            }
        }

        LaunchedEffect(messages, imeBottom) {
            if (messages.isNotEmpty()) {
                listState.animateScrollToItem(messages.size - 1)
            }
        }

        val cameraAudioPermissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->
            val cameraGranted = permissions[android.Manifest.permission.CAMERA] ?: false
            val audioGranted = permissions[android.Manifest.permission.RECORD_AUDIO] ?: false
            if (cameraGranted && audioGranted) {
                viewModel.startVideoCall()
            } else {
                Toast.makeText(context, "يلزم إذن الكاميرا والميكروفون لإجراء مكالمة فيديو", Toast.LENGTH_SHORT).show()
            }
        }

        val voiceCallPermissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                viewModel.startVoiceCall()
            } else {
                Toast.makeText(context, "يلزم إذن الميكروفون لإجراء مكالمة صوتية", Toast.LENGTH_SHORT).show()
            }
        }

        val imagePickerLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri: Uri? ->
            uri?.let { viewModel.sendImageUri(it) }
        }

        val filePickerLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri: Uri? ->
            uri?.let {
                val fileName = uri.lastPathSegment ?: "file_${System.currentTimeMillis()}"
                viewModel.sendFileUri(it, fileName)
            }
        }

        Scaffold(
            contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0),
            containerColor = Color(0xFFEFEAE2), // WhatsApp Classic Chat Background
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            listOf(Color(0xFF2563EB), Color(0xFF1D4ED8))
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = targetDeviceName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color(0xFF111B21),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(if (isPeerOnline) OnlineGreen else OfflineGray)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isPeerTyping) "يكتب الآن..." else if (isPeerOnline) "متصل الآن" else "غير متصل",
                                        fontSize = 10.5.sp,
                                        color = if (isPeerTyping) Color(0xFF00A884) else Color(0xFF667781),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onBackClick) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع",
                                tint = Color(0xFF111B21)
                            )
                        }
                    },
                    actions = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            // Video Call Button
                            Box(
                                modifier = Modifier
                                    .padding(end = 6.dp)
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00A884).copy(alpha = 0.15f))
                                    .clickable {
                                        val hasCam = ContextCompat.checkSelfPermission(context, android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                                        val hasMic = ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                                        if (hasCam && hasMic) {
                                            viewModel.startVideoCall()
                                        } else {
                                            cameraAudioPermissionLauncher.launch(
                                                arrayOf(android.Manifest.permission.CAMERA, android.Manifest.permission.RECORD_AUDIO)
                                            )
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Videocam,
                                    contentDescription = "اتصال فيديو",
                                    tint = Color(0xFF00A884),
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            // Voice Call Button
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00A884).copy(alpha = 0.15f))
                                    .clickable {
                                        val hasMic = ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                                        if (hasMic) {
                                            viewModel.startVoiceCall()
                                        } else {
                                            voiceCallPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Phone,
                                    contentDescription = "مكالمة صوتية",
                                    tint = Color(0xFF00A884),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            }
        ) { innerPadding ->

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .imePadding()
                    .navigationBarsPadding()
            ) {
                Column(modifier = Modifier.fillMaxSize()) {

                    // Offline Notice Banner
                    AnimatedVisibility(visible = !isPeerOnline) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = Color(0xFFFEF2F2)
                        ) {
                            Text(
                                text = "الجهاز غير متصل بالشبكة المحلية - ستصل الرسائل فور إعادته",
                                color = Color(0xFFDC2626),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(vertical = 6.dp, horizontal = 16.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    // End-to-End Encryption Banner
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFFFEECD)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = Color(0xFF856404),
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "المحادثات والمكالمات مشفرة نداً للند محلياً (Direct UDP/TCP)",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF856404)
                                )
                            }
                        }
                    }

                    // Chat Messages List
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(messages, key = { it.id }) { message ->
                            WhatsAppMessageBubble(
                                message = message,
                                audioState = audioState,
                                onPlayAudio = { viewModel.playAudio(message.id, it) },
                                onSaveFile = { path, name -> viewModel.saveFileToPublicDownloads(path, name) },
                                onOpenFile = { path -> openFile(context, path) }
                            )
                        }
                    }

                    // Attachment Menu Popup
                    AnimatedVisibility(visible = showAttachmentMenu) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceAround,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AttachmentMenuItem(
                                    icon = Icons.Default.Image,
                                    label = "معرض الصور",
                                    color = Color(0xFF7F66FF),
                                    onClick = {
                                        showAttachmentMenu = false
                                        imagePickerLauncher.launch("image/*")
                                    }
                                )
                                AttachmentMenuItem(
                                    icon = Icons.Default.InsertDriveFile,
                                    label = "مستند / ملف",
                                    color = Color(0xFF00A884),
                                    onClick = {
                                        showAttachmentMenu = false
                                        filePickerLauncher.launch("*/*")
                                    }
                                )
                                AttachmentMenuItem(
                                    icon = Icons.Default.Mic,
                                    label = "تسجيل صوتي",
                                    color = Color(0xFFE91E63),
                                    onClick = {
                                        showAttachmentMenu = false
                                        viewModel.startRecordingAudio()
                                    }
                                )
                            }
                        }
                    }

                    // Bottom Bar Input
                    Surface(
                        color = Color(0xFFF0F2F5),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isRecordingAudio) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(Color.Red)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = "تسجيل صوتي: %02d:%02d".format(
                                            recordingDurationSeconds / 60,
                                            recordingDurationSeconds % 60
                                        ),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color(0xFF111B21)
                                    )
                                }

                                Row {
                                    IconButton(onClick = { viewModel.cancelAudioRecording() }) {
                                        Icon(Icons.Default.Close, contentDescription = "إلغاء", tint = Color.Red)
                                    }
                                    IconButton(onClick = { viewModel.stopAndSendAudioRecording() }) {
                                        Icon(Icons.Default.Stop, contentDescription = "إرسال", tint = Color(0xFF00A884))
                                    }
                                }
                            }
                        } else {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = { showAttachmentMenu = !showAttachmentMenu }) {
                                    Icon(Icons.Default.Add, contentDescription = "إضافة", tint = Color(0xFF54656F))
                                }

                                OutlinedTextField(
                                    value = inputText,
                                    onValueChange = {
                                        inputText = it
                                        viewModel.sendTypingNotification(it.isNotEmpty())
                                    },
                                    placeholder = { Text("اكتب رسالة...", color = Color(0xFF667781), fontSize = 14.sp) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(24.dp),
                                    maxLines = 4,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = Color.Transparent,
                                        unfocusedBorderColor = Color.Transparent,
                                        unfocusedContainerColor = Color.White,
                                        focusedContainerColor = Color.White
                                    ),
                                    trailingIcon = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            IconButton(onClick = { imagePickerLauncher.launch("image/*") }) {
                                                Icon(Icons.Default.CameraAlt, contentDescription = "كاميرا", tint = Color(0xFF54656F))
                                            }
                                        }
                                    }
                                )

                                Spacer(modifier = Modifier.width(6.dp))

                                if (inputText.isNotBlank()) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF00A884))
                                            .clickable {
                                                viewModel.sendTextMessage(inputText)
                                                inputText = ""
                                                viewModel.sendTypingNotification(false)
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Send,
                                            contentDescription = "إرسال",
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                } else {
                                    // Mic Button for Audio Recording when input text is empty
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF00A884))
                                            .clickable { viewModel.startRecordingAudio() },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Mic,
                                            contentDescription = "تسجيل صوتي",
                                            tint = Color.White,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Voice & Video Call Overlay Dialog
                if (callInfo.state != CallState.IDLE) {
                    val remoteVideoFrame by viewModel.remoteVideoFrame.collectAsStateWithLifecycle()
                    VoiceCallDialog(
                        callInfo = callInfo,
                        remoteVideoFrame = remoteVideoFrame,
                        onAccept = { viewModel.acceptCall() },
                        onReject = { viewModel.rejectCall() },
                        onToggleMute = { viewModel.toggleMuteCall() },
                        onToggleSpeaker = { viewModel.toggleSpeakerCall() },
                        onToggleCamera = { viewModel.toggleCameraCall() },
                        onSwitchCamera = { viewModel.switchCameraCall() },
                        onSendVideoFrame = { viewModel.sendVideoFrame(it) },
                        onEndCall = { viewModel.endVoiceCall() }
                    )
                }
            }
        }
    }
}

@Composable
fun WhatsAppMessageBubble(
    message: Message,
    audioState: AudioPlaybackState,
    onPlayAudio: (filePath: String) -> Unit,
    onSaveFile: (filePath: String, fileName: String) -> Unit,
    onOpenFile: (filePath: String) -> Unit
) {
    val isMe = message.isFromMe

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isMe) Alignment.End else Alignment.Start
    ) {
        Card(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isMe) 16.dp else 2.dp,
                bottomEnd = if (isMe) 2.dp else 16.dp
            ),
            colors = CardDefaults.cardColors(
                containerColor = if (isMe) Color(0xFFDCF8C6) else Color.White
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
            modifier = Modifier.widthIn(max = 310.dp)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {

                when (message.type) {
                    MessageType.TEXT -> {
                        Text(
                            text = message.textContent,
                            color = Color(0xFF111B21),
                            fontSize = 15.sp,
                            lineHeight = 22.sp,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }

                    MessageType.IMAGE -> {
                        message.filePath?.let { path ->
                            val file = File(path)
                            if (file.exists()) {
                                Column {
                                    AsyncImage(
                                        model = file,
                                        contentDescription = "صورة",
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(200.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { onOpenFile(path) },
                                        contentScale = ContentScale.Crop
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            modifier = Modifier.clickable { onOpenFile(path) },
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Visibility,
                                                contentDescription = null,
                                                tint = Color(0xFF00A884),
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "فتح الصورة",
                                                fontSize = 12.sp,
                                                color = Color(0xFF00A884),
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        Row(
                                            modifier = Modifier.clickable {
                                                onSaveFile(path, message.fileName ?: "IMAGE_${message.id}.jpg")
                                            },
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Download,
                                                contentDescription = null,
                                                tint = Color(0xFF54656F),
                                                modifier = Modifier.size(15.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "حفظ",
                                                fontSize = 11.5.sp,
                                                color = Color(0xFF54656F)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    MessageType.AUDIO -> {
                        message.filePath?.let { path ->
                            val isPlayingThis = audioState.playingMessageId == message.id && audioState.isPlaying
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF00A884))
                                        .clickable { onPlayAudio(path) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isPlayingThis) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(20.dp),
                                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        val heights = listOf(6, 12, 18, 10, 16, 8, 14, 20, 12, 6, 14, 18, 10, 16)
                                        heights.forEach { h ->
                                            Box(
                                                modifier = Modifier
                                                    .width(3.dp)
                                                    .height(h.dp)
                                                    .clip(RoundedCornerShape(2.dp))
                                                    .background(Color(0xFF00A884).copy(alpha = 0.8f))
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "%02d:%02d".format(
                                            (message.audioDurationMs / 1000) / 60,
                                            (message.audioDurationMs / 1000) % 60
                                        ),
                                        fontSize = 11.sp,
                                        color = Color(0xFF667781)
                                    )
                                }
                            }
                        }
                    }

                    MessageType.FILE -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFFF0F2F5))
                                .clickable {
                                    message.filePath?.let { path -> onOpenFile(path) }
                                }
                                .padding(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF00A884).copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.InsertDriveFile,
                                    contentDescription = null,
                                    tint = Color(0xFF00A884),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = message.fileName ?: "مستند.pdf",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF111B21),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${formatFileSize(message.fileSize)} • انقر للفتح المباشر",
                                    fontSize = 11.sp,
                                    color = Color(0xFF00A884),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            message.filePath?.let { path ->
                                IconButton(
                                    onClick = { onSaveFile(path, message.fileName ?: "FILE_${message.id}") }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Download,
                                        contentDescription = "حفظ",
                                        tint = Color(0xFF54656F),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = formatMsgTime(message.timestamp),
                        fontSize = 10.sp,
                        color = Color(0xFF667781)
                    )
                    if (isMe) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = when (message.status) {
                                MessageStatus.SENDING -> "..."
                                MessageStatus.SENT -> "✓"
                                MessageStatus.DELIVERED -> "✓✓"
                                MessageStatus.READ -> "✓✓"
                            },
                            fontSize = 11.sp,
                            color = if (message.status == MessageStatus.READ) Color(0xFF53BDEB) else Color(0xFF8696A0),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AttachmentMenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(color),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF111B21))
    }
}

@Composable
fun VoiceCallDialog(
    callInfo: CallInfo,
    remoteVideoFrame: android.graphics.Bitmap? = null,
    onAccept: () -> Unit,
    onReject: () -> Unit,
    onToggleMute: () -> Unit,
    onToggleSpeaker: () -> Unit,
    onToggleCamera: (() -> Unit)? = null,
    onSwitchCamera: (() -> Unit)? = null,
    onSendVideoFrame: ((android.graphics.Bitmap) -> Unit)? = null,
    onEndCall: () -> Unit
) {
    Dialog(
        onDismissRequest = { },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF0B141A) // Dark Call Screen
        ) {
            if (callInfo.isVideoCall) {
                // Modern Full Screen Video Call Layout
                Box(modifier = Modifier.fillMaxSize()) {
                    // 1. Full Screen Remote Peer Video or Backdrop
                    if (remoteVideoFrame != null) {
                        Image(
                            bitmap = remoteVideoFrame.asImageBitmap(),
                            contentDescription = "بث فيديو الطرف الآخر",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0xFF0F172A)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(110.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF00A884)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(60.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(20.dp))
                                Text(
                                    text = callInfo.targetName.ifEmpty { "جهاز محلي" },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 24.sp,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = when (callInfo.state) {
                                        CallState.OUTGOING_RINGING -> "جاري طلب اتصال الفيديو المباشر عبر IP (${callInfo.targetIp})..."
                                        CallState.INCOMING_RINGING -> "دعوة مكالمة فيديو واردة..."
                                        CallState.CONNECTED -> "جاري استقبال وتزامن بث الفيديو المباشر..."
                                        CallState.ENDED -> "تم إنهاء المكالمة"
                                        CallState.IDLE -> ""
                                    },
                                    fontSize = 14.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }
                    }

                    // 2. Floating Local Camera Preview Window (Picture-in-Picture)
                    if (callInfo.state == CallState.CONNECTED || callInfo.state == CallState.OUTGOING_RINGING) {
                        Box(
                            modifier = Modifier
                                .padding(top = 48.dp, end = 20.dp)
                                .align(Alignment.TopEnd)
                                .size(width = 115.dp, height = 155.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .border(2.dp, Color(0xFF00A884), RoundedCornerShape(18.dp))
                                .background(Color.Black)
                        ) {
                            CameraPreviewView(
                                isFrontCamera = callInfo.isFrontCamera,
                                isCameraOn = callInfo.isCameraOn,
                                modifier = Modifier.fillMaxSize(),
                                onFrameCaptured = onSendVideoFrame
                            )
                        }
                    }

                    // 3. Top Header Status Overlay
                    Column(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(top = 48.dp, start = 20.dp)
                    ) {
                        Text(
                            text = callInfo.targetName.ifEmpty { "مكالمة فيديو P2P" },
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = when (callInfo.state) {
                                CallState.CONNECTED -> "🔴 فيديو مباشر %02d:%02d".format(callInfo.durationSeconds / 60, callInfo.durationSeconds % 60)
                                CallState.OUTGOING_RINGING -> "جاري الرنين..."
                                CallState.INCOMING_RINGING -> "مكالمة فيديو واردة..."
                                CallState.ENDED -> "تم إنهاء المكالمة"
                                CallState.IDLE -> ""
                            },
                            color = Color(0xFF00A884),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "شبكة محلية P2P • دقة متكيفة تلقائياً",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }

                    // 4. Bottom Control Bar Overlay
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 36.dp)
                            .clip(RoundedCornerShape(32.dp))
                            .background(Color.Black.copy(alpha = 0.75f))
                            .padding(horizontal = 20.dp, vertical = 12.dp)
                    ) {
                        if (callInfo.state == CallState.INCOMING_RINGING) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(36.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFEA4335))
                                        .clickable { onReject() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CallEnd,
                                        contentDescription = "رفض",
                                        tint = Color.White,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF00A884))
                                        .clickable { onAccept() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Videocam,
                                        contentDescription = "رد فيديو",
                                        tint = Color.White,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                        } else {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Mute Audio
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(if (callInfo.isMuted) Color.White else Color(0xFF334155))
                                        .clickable { onToggleMute() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (callInfo.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                        contentDescription = "كتم الصوت",
                                        tint = if (callInfo.isMuted) Color.Black else Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                // Toggle Camera
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(if (!callInfo.isCameraOn) Color.White else Color(0xFF334155))
                                        .clickable { onToggleCamera?.invoke() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (callInfo.isCameraOn) Icons.Default.Videocam else Icons.Default.VideocamOff,
                                        contentDescription = "الكاميرا",
                                        tint = if (!callInfo.isCameraOn) Color.Black else Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                // Switch Camera (Front/Back)
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF334155))
                                        .clickable { onSwitchCamera?.invoke() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Cameraswitch,
                                        contentDescription = "تبديل الكاميرا",
                                        tint = Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                // End Call
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFEA4335))
                                        .clickable { onEndCall() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CallEnd,
                                        contentDescription = "إنهاء المكالمة",
                                        tint = Color.White,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                // Voice Call Layout
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(top = 40.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00A884)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(60.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Text(
                            text = callInfo.targetName.ifEmpty { "جهاز محلي" },
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = when (callInfo.state) {
                                CallState.OUTGOING_RINGING -> "جاري طلب الاتصال عبر IP (${callInfo.targetIp})..."
                                CallState.INCOMING_RINGING -> "مكالمة صوتية واردة..."
                                CallState.CONNECTED -> "مكالمة جارية 🟢 %02d:%02d".format(callInfo.durationSeconds / 60, callInfo.durationSeconds % 60)
                                CallState.ENDED -> "تم إنهاء المكالمة"
                                CallState.IDLE -> ""
                            },
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (callInfo.state == CallState.CONNECTED) Color(0xFF00A884) else Color(0xFF8696A0)
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "🔒 بث صوتي حقيقي مشفر (PCM 16kHz UDP Direct)",
                            fontSize = 11.sp,
                            color = Color(0xFF00A884)
                        )
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(bottom = 40.dp)
                    ) {
                        if (callInfo.state == CallState.INCOMING_RINGING) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(48.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(
                                        modifier = Modifier
                                            .size(64.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFEA4335))
                                            .clickable { onReject() },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CallEnd,
                                            contentDescription = "رفض",
                                            tint = Color.White,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("رفض", color = Color.White, fontSize = 13.sp)
                                }

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(
                                        modifier = Modifier
                                            .size(64.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF00A884))
                                            .clickable { onAccept() },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Call,
                                            contentDescription = "رد",
                                            tint = Color.White,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("رد", color = Color.White, fontSize = 13.sp)
                                }
                            }
                        } else {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(28.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(if (callInfo.isMuted) Color.White else Color(0xFF202C33))
                                        .clickable { onToggleMute() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (callInfo.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                        contentDescription = "كتم الصوت",
                                        tint = if (callInfo.isMuted) Color.Black else Color.White,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(if (callInfo.isSpeakerOn) Color(0xFF00A884) else Color(0xFF202C33))
                                        .clickable { onToggleSpeaker() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VolumeUp,
                                        contentDescription = "مكبر الصوت",
                                        tint = Color.White,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFEA4335))
                                        .clickable { onEndCall() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CallEnd,
                                        contentDescription = "إنهاء المكالمة",
                                        tint = Color.White,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatMsgTime(timestamp: Long): String {
    val date = Date(timestamp)
    val sdf = SimpleDateFormat("hh:mm a", Locale("ar"))
    return sdf.format(date)
}

private fun formatFileSize(size: Long): String {
    if (size <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB")
    val digitGroups = (Math.log10(size.toDouble()) / Math.log10(1024.0)).toInt()
    return "%.1f %s".format(size / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
}

private fun openFile(context: Context, filePath: String) {
    try {
        val file = File(filePath)
        if (!file.exists()) {
            Toast.makeText(context, "الملف غير موجود على الجهاز", Toast.LENGTH_SHORT).show()
            return
        }
        val uri: Uri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val ext = file.extension.lowercase(Locale.ROOT)
        val mimeType = context.contentResolver.getType(uri) ?: when (ext) {
            "pdf" -> "application/pdf"
            "jpg", "jpeg", "png", "webp" -> "image/*"
            "mp3", "wav", "m4a", "aac", "ogg" -> "audio/*"
            "mp4", "mkv", "3gp" -> "video/*"
            "txt" -> "text/plain"
            "doc", "docx" -> "application/msword"
            "xls", "xlsx" -> "application/vnd.ms-excel"
            "zip", "rar" -> "application/zip"
            else -> "*/*"
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "تعذر فتح الملف: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
}
