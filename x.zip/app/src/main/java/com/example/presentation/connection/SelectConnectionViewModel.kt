package com.example.presentation.connection

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.data.local.preferences.UserPreferences
import com.example.util.NetworkUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class SelectConnectionViewModel(application: Application) : AndroidViewModel(application) {

    private val userPrefs = UserPreferences(application)

    val savedMode: StateFlow<String?> = userPrefs.connectionMode

    private val _isWifiConnected = MutableStateFlow(NetworkUtils.isWifiConnected(application))
    val isWifiConnected: StateFlow<Boolean> = _isWifiConnected

    private val _isHotspotNetworkAvailable = MutableStateFlow(NetworkUtils.isHotspotOrLocalNetworkAvailable(application))
    val isHotspotNetworkAvailable: StateFlow<Boolean> = _isHotspotNetworkAvailable

    fun refreshNetworkStatus() {
        _isWifiConnected.value = NetworkUtils.isWifiConnected(getApplication())
        _isHotspotNetworkAvailable.value = NetworkUtils.isHotspotOrLocalNetworkAvailable(getApplication())
    }

    fun selectMode(
        mode: String = UserPreferences.MODE_HOTSPOT,
        forceProceed: Boolean = false,
        onSuccess: () -> Unit,
        onRequireWifiAlert: () -> Unit,
        onRequireHotspotAlert: () -> Unit
    ) {
        refreshNetworkStatus()

        userPrefs.setConnectionMode(UserPreferences.MODE_HOTSPOT)
        if (forceProceed || _isHotspotNetworkAvailable.value || _isWifiConnected.value) {
            onSuccess()
        } else {
            onRequireHotspotAlert()
        }
    }
}
