package com.example.presentation.connection

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.preferences.UserPreferences

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SelectConnectionScreen(
    viewModel: SelectConnectionViewModel,
    onConnectionSelected: () -> Unit
) {
    val context = LocalContext.current

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {

        val isWifiConnected by viewModel.isWifiConnected.collectAsStateWithLifecycle()
        val isHotspotNetworkAvailable by viewModel.isHotspotNetworkAvailable.collectAsStateWithLifecycle()
        val savedMode by viewModel.savedMode.collectAsStateWithLifecycle()

        var showWifiDialog by remember { mutableStateOf(false) }
        var showHotspotDialog by remember { mutableStateOf(false) }

        LaunchedEffect(Unit) {
            viewModel.refreshNetworkStatus()
        }

        Scaffold(
            containerColor = Color(0xFFF8FAFC),
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "واصل • شبكة محلية",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color(0xFF1E293B)
                        )
                    },
                    actions = {
                        IconButton(onClick = { viewModel.refreshNetworkStatus() }) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تحديث حالة الشبكة",
                                tint = Color(0xFF2563EB)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            }
        ) { innerPadding ->

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Spacer(modifier = Modifier.height(10.dp))

                // Header Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF1E3A8A), Color(0xFF2563EB), Color(0xFF3B82F6))
                            )
                        )
                        .padding(24.dp)
                ) {
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = "اختيار طريقة الاتصال",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "اختر طريقة الربط المناسبة للاتصال بالأجهزة القريبة وبدء المراسلة الفورية بدون إنترنت.",
                            fontSize = 14.sp,
                            color = Color(0xFFE0F2FE),
                            lineHeight = 22.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Primary Hotspot Card
                ConnectionOptionCard(
                    title = "📡 نقطة الاتصال الشخصية (Personal Hotspot)",
                    description = "يقوم أحد الأجهزة بفتح نقطة الاتصال (Hotspot) ويتصل الجهاز الآخر بها، ليتم اكتشاف الأجهزة والمراسلة الفورية كلياً بدون خوادم ولا إنترنت.",
                    icon = Icons.Default.CellTower,
                    iconTint = Color(0xFF7C3AED),
                    iconBg = Color(0xFFF5F3FF),
                    isConnected = isHotspotNetworkAvailable,
                    statusText = if (isHotspotNetworkAvailable) "شبكة Hotspot متاحة" else "في انتظار الاتصال بـ Hotspot",
                    isSelected = true,
                    onSelect = {
                        viewModel.selectMode(
                            mode = UserPreferences.MODE_HOTSPOT,
                            onSuccess = onConnectionSelected,
                            onRequireWifiAlert = {},
                            onRequireHotspotAlert = { showHotspotDialog = true }
                        )
                    }
                )

                Spacer(modifier = Modifier.height(30.dp))

                Text(
                    text = "🔒 جميع المحادثات تنقل مباشرة بين الأجهزة في نفس الشبكة المحلية وبدون إنترنت.",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B),
                    textAlign = TextAlign.Center
                )
            }

            // Wi-Fi Connection Required Dialog
            if (showWifiDialog) {
                AlertDialog(
                    onDismissRequest = { showWifiDialog = false },
                    containerColor = Color.White,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFD97706))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("الاتصال بشبكة Wi-Fi مطلوب", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                    },
                    text = {
                        Text(
                            text = "الجهاز غير متصل حالياً بأي شبكة Wi-Fi. يرجى الاتصال بشبكة الواي فاي للبدء باكتشاف الأجهزة القريبة.",
                            fontSize = 14.sp,
                            color = Color(0xFF334155),
                            lineHeight = 22.sp
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                try {
                                    context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                                } catch (e: Exception) {
                                    // Fallback
                                }
                                showWifiDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("فتح إعدادات Wi-Fi", fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = {
                            viewModel.selectMode(
                                mode = UserPreferences.MODE_HOTSPOT,
                                forceProceed = true,
                                onSuccess = onConnectionSelected,
                                onRequireWifiAlert = {},
                                onRequireHotspotAlert = {}
                            )
                            showWifiDialog = false
                        }) {
                            Text("متابعة على أي حال", color = Color(0xFF64748B))
                        }
                    }
                )
            }

            // Hotspot Connection Instructions Dialog
            if (showHotspotDialog) {
                AlertDialog(
                    onDismissRequest = { showHotspotDialog = false },
                    containerColor = Color.White,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CellTower, contentDescription = null, tint = Color(0xFF7C3AED))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("توجيهات نقطة الاتصال (Hotspot)", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                    },
                    text = {
                        Column {
                            Text(
                                text = "1. قم بتشغيل نقطة الاتصال (Hotspot) على أحد الجهازين.\n2. اربط الجهاز الثاني بنقطة الاتصال التي تم إنشاؤها.\n3. اضغط متابعة للبدء باكتشاف الأجهزة.",
                                fontSize = 14.sp,
                                color = Color(0xFF334155),
                                lineHeight = 24.sp
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.selectMode(
                                    mode = UserPreferences.MODE_HOTSPOT,
                                    forceProceed = true,
                                    onSuccess = onConnectionSelected,
                                    onRequireWifiAlert = {},
                                    onRequireHotspotAlert = {}
                                )
                                showHotspotDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("متابعة واستكشاف", fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        OutlinedButton(
                            onClick = {
                                try {
                                    context.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
                                } catch (e: Exception) {
                                    // Fallback
                                }
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("فتح الإعدادات", fontSize = 13.sp)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun ConnectionOptionCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    iconBg: Color,
    isConnected: Boolean,
    statusText: String,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable { onSelect() },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, iconTint) else null
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(iconBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(24.dp))
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Text(
                        text = title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = description,
                fontSize = 13.sp,
                color = Color(0xFF475569),
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Status Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(30.dp))
                        .background(if (isConnected) Color(0xFFDCFCE7) else Color(0xFFFEF3C7))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isConnected) Color(0xFF16A34A) else Color(0xFFD97706))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = statusText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isConnected) Color(0xFF15803D) else Color(0xFFB45309)
                        )
                    }
                }

                // Action Button
                Button(
                    onClick = onSelect,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = iconTint)
                ) {
                    Text("اختيار وتوصيل", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
