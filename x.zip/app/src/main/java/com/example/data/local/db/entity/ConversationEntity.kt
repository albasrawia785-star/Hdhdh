package com.example.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.Conversation

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val targetDeviceId: String,
    val targetDeviceName: String,
    val targetIpAddress: String,
    val lastMessage: String,
    val lastMessageTimestamp: Long,
    val unreadCount: Int,
    val isAccepted: Boolean,
    val avatarBase64: String = ""
) {
    fun toDomain(
        isOnline: Boolean = false,
        avatarBase64: String = this.avatarBase64,
        targetDeviceName: String = this.targetDeviceName
    ): Conversation {
        return Conversation(
            id = targetDeviceId,
            targetDeviceId = targetDeviceId,
            targetDeviceName = targetDeviceName,
            targetIpAddress = targetIpAddress,
            lastMessage = lastMessage,
            lastMessageTimestamp = lastMessageTimestamp,
            unreadCount = unreadCount,
            isAccepted = isAccepted,
            isOnline = isOnline,
            avatarBase64 = avatarBase64
        )
    }

    companion object {
        fun fromDomain(domain: Conversation): ConversationEntity {
            return ConversationEntity(
                targetDeviceId = domain.targetDeviceId,
                targetDeviceName = domain.targetDeviceName,
                targetIpAddress = domain.targetIpAddress,
                lastMessage = domain.lastMessage,
                lastMessageTimestamp = domain.lastMessageTimestamp,
                unreadCount = domain.unreadCount,
                isAccepted = domain.isAccepted,
                avatarBase64 = domain.avatarBase64
            )
        }
    }
}
