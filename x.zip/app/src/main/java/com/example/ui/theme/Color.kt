package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MessengerPrimary = Color(0xFF2563EB)
val MessengerCyan = Color(0xFF06B6D4)
val OnlineGreen = Color(0xFF22C55E)
val OfflineGray = Color(0xFF94A3B8)
val AppBorder = Color(0xFFE5E7EB)

val PrimaryLight = Color(0xFF2563EB)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFD2E3FF)
val OnPrimaryContainerLight = Color(0xFF001B3E)

val SecondaryLight = Color(0xFF06B6D4)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF0F172A)
val SurfaceVariantLight = Color(0xFFF8FAFC)
val OnSurfaceVariantLight = Color(0xFF475569)

val PrimaryDark = Color(0xFF3B82F6)
val OnPrimaryDark = Color(0xFF002B5C)
val PrimaryContainerDark = Color(0xFF00438A)
val OnPrimaryContainerDark = Color(0xFFD2E3FF)

val SurfaceDark = Color(0xFF0F172A)
val OnSurfaceDark = Color(0xFFF8FAFC)
val SurfaceVariantDark = Color(0xFF1E293B)
val OnSurfaceVariantDark = Color(0xFF94A3B8)

