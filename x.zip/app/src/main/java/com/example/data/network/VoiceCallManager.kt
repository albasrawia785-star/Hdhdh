package com.example.data.network

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicBoolean

data class CallInfo(
    val state: CallState = CallState.IDLE,
    val targetDeviceId: String = "",
    val targetName: String = "",
    val targetIp: String = "",
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = true,
    val isVideoCall: Boolean = false,
    val isCameraOn: Boolean = true,
    val isFrontCamera: Boolean = true,
    val durationSeconds: Int = 0
)

enum class CallState {
    IDLE,
    OUTGOING_RINGING,
    INCOMING_RINGING,
    CONNECTED,
    ENDED
}

class VoiceCallManager private constructor(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _callInfo = MutableStateFlow(CallInfo())
    val callInfo: StateFlow<CallInfo> = _callInfo.asStateFlow()

    private val _remoteVideoFrame = MutableStateFlow<Bitmap?>(null)
    val remoteVideoFrame: StateFlow<Bitmap?> = _remoteVideoFrame.asStateFlow()

    private val isCallActive = AtomicBoolean(false)
    private var udpAudioSocket: DatagramSocket? = null
    private var udpVideoSocket: DatagramSocket? = null
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var toneGenerator: ToneGenerator? = null

    private var durationTimerJob: kotlinx.coroutines.Job? = null

    // Adaptive Resolution variables
    private var lastFrameTimeMs = 0L
    private var adaptiveQuality = 60

    companion object {
        const val AUDIO_PORT = 9998
        const val VIDEO_PORT = 9997
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_CONFIG_IN = AudioFormat.CHANNEL_IN_MONO
        private const val CHANNEL_CONFIG_OUT = AudioFormat.CHANNEL_OUT_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val TAG = "VoiceCallManager"

        @Volatile
        private var INSTANCE: VoiceCallManager? = null

        fun getInstance(context: Context): VoiceCallManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: VoiceCallManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    fun initiateCall(targetDeviceId: String, targetName: String, targetIp: String, isVideo: Boolean = false) {
        if (_callInfo.value.state != CallState.IDLE) return

        _callInfo.value = CallInfo(
            state = CallState.OUTGOING_RINGING,
            targetDeviceId = targetDeviceId,
            targetName = targetName,
            targetIp = targetIp,
            isVideoCall = isVideo,
            isCameraOn = true,
            isFrontCamera = true
        )

        playRingbackTone()
    }

    fun receiveIncomingCall(senderDeviceId: String, senderName: String, senderIp: String, isVideo: Boolean = false) {
        if (_callInfo.value.state != CallState.IDLE) return

        _callInfo.value = CallInfo(
            state = CallState.INCOMING_RINGING,
            targetDeviceId = senderDeviceId,
            targetName = senderName,
            targetIp = senderIp,
            isVideoCall = isVideo,
            isCameraOn = true,
            isFrontCamera = true
        )

        playIncomingRingtone()
    }

    fun acceptIncomingCall() {
        stopTone()
        val current = _callInfo.value
        startCallStreams(current.targetIp)
    }

    fun rejectIncomingCall() {
        stopTone()
        playHangupTone()
        _callInfo.value = _callInfo.value.copy(state = CallState.ENDED)
        scope.launch {
            kotlinx.coroutines.delay(1000)
            resetCallState()
        }
    }

    fun onCallAcceptedByPeer() {
        stopTone()
        val current = _callInfo.value
        startCallStreams(current.targetIp)
    }

    fun onCallEndedByPeer() {
        stopCallStreams()
        stopTone()
        playHangupTone()
        _callInfo.value = _callInfo.value.copy(state = CallState.ENDED)
        scope.launch {
            kotlinx.coroutines.delay(1000)
            resetCallState()
        }
    }

    fun endCall() {
        stopCallStreams()
        stopTone()
        playHangupTone()
        _callInfo.value = _callInfo.value.copy(state = CallState.ENDED)
        scope.launch {
            kotlinx.coroutines.delay(1000)
            resetCallState()
        }
    }

    fun toggleMute(): Boolean {
        val newMute = !_callInfo.value.isMuted
        _callInfo.value = _callInfo.value.copy(isMuted = newMute)
        return newMute
    }

    fun toggleSpeaker(): Boolean {
        val newSpeaker = !_callInfo.value.isSpeakerOn
        _callInfo.value = _callInfo.value.copy(isSpeakerOn = newSpeaker)
        audioManager.isSpeakerphoneOn = newSpeaker
        return newSpeaker
    }

    fun toggleCamera(): Boolean {
        val newCam = !_callInfo.value.isCameraOn
        _callInfo.value = _callInfo.value.copy(isCameraOn = newCam)
        return newCam
    }

    fun switchCamera(): Boolean {
        val newFront = !_callInfo.value.isFrontCamera
        _callInfo.value = _callInfo.value.copy(isFrontCamera = newFront)
        return newFront
    }

    /**
     * Sends a captured local camera video frame over UDP with Adaptive Resolution & Compression.
     */
    fun sendVideoFrame(bitmap: Bitmap) {
        val current = _callInfo.value
        if (!isCallActive.get() || !current.isVideoCall || !current.isCameraOn) return

        scope.launch(Dispatchers.IO) {
            try {
                val targetIp = current.targetIp
                if (targetIp.isBlank()) return@launch

                // Calculate Adaptive Quality & Resolution based on frame latency
                val now = System.currentTimeMillis()
                val latency = if (lastFrameTimeMs > 0) now - lastFrameTimeMs else 60
                lastFrameTimeMs = now

                if (latency > 150) {
                    adaptiveQuality = (adaptiveQuality - 5).coerceAtLeast(25)
                } else if (latency < 70) {
                    adaptiveQuality = (adaptiveQuality + 3).coerceAtMost(70)
                }

                // Scale bitmap for UDP optimization
                val targetWidth = if (adaptiveQuality < 45) 240 else 360
                val scaled = if (bitmap.width > targetWidth) {
                    val aspect = bitmap.height.toFloat() / bitmap.width.toFloat()
                    Bitmap.createScaledBitmap(bitmap, targetWidth, (targetWidth * aspect).toInt(), true)
                } else {
                    bitmap
                }

                val baos = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, adaptiveQuality, baos)
                val bytes = baos.toByteArray()

                if (bytes.size < 65000) {
                    val destAddress = if (targetIp == "127.0.0.1") InetAddress.getLoopbackAddress() else InetAddress.getByName(targetIp)
                    val packet = DatagramPacket(bytes, bytes.size, destAddress, VIDEO_PORT)
                    udpVideoSocket?.send(packet)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error sending UDP video frame", e)
            }
        }
    }

    private fun startCallStreams(targetIp: String) {
        if (isCallActive.getAndSet(true)) return

        _remoteVideoFrame.value = null
        _callInfo.value = _callInfo.value.copy(state = CallState.CONNECTED, durationSeconds = 0)

        // Start call duration timer
        durationTimerJob?.cancel()
        durationTimerJob = scope.launch {
            while (isCallActive.get()) {
                kotlinx.coroutines.delay(1000)
                _callInfo.value = _callInfo.value.copy(
                    durationSeconds = _callInfo.value.durationSeconds + 1
                )
            }
        }

        try {
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager.isSpeakerphoneOn = _callInfo.value.isSpeakerOn || _callInfo.value.isVideoCall
        } catch (e: Exception) {
            Log.e(TAG, "Error configuring audio manager", e)
        }

        // Start UDP Audio & Video sockets
        scope.launch(Dispatchers.IO) {
            try {
                udpAudioSocket = DatagramSocket(AUDIO_PORT)
            } catch (e: Exception) {
                Log.e(TAG, "Audio port $AUDIO_PORT busy, reusing socket", e)
                try {
                    udpAudioSocket = DatagramSocket(null).apply {
                        reuseAddress = true
                        bind(java.net.InetSocketAddress(AUDIO_PORT))
                    }
                } catch (ex: Exception) {
                    Log.e(TAG, "Failed to bind UDP audio socket", ex)
                }
            }

            try {
                udpVideoSocket = DatagramSocket(VIDEO_PORT)
            } catch (e: Exception) {
                Log.e(TAG, "Video port $VIDEO_PORT busy, reusing socket", e)
                try {
                    udpVideoSocket = DatagramSocket(null).apply {
                        reuseAddress = true
                        bind(java.net.InetSocketAddress(VIDEO_PORT))
                    }
                } catch (ex: Exception) {
                    Log.e(TAG, "Failed to bind UDP video socket", ex)
                }
            }

            launchPlayerThread()
            launchRecorderThread(targetIp)

            if (_callInfo.value.isVideoCall) {
                launchVideoReceiverThread()
            }
        }
    }

    private fun launchPlayerThread() {
        scope.launch(Dispatchers.IO) {
            val minBufferSize = AudioTrack.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG_OUT, AUDIO_FORMAT)
            val bufferSize = Math.max(minBufferSize, 2048)

            try {
                audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AUDIO_FORMAT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(CHANNEL_CONFIG_OUT)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                audioTrack?.play()
            } catch (e: Exception) {
                Log.e(TAG, "Error initializing AudioTrack", e)
            }

            val receiveBuffer = ByteArray(2048)
            while (isCallActive.get()) {
                try {
                    val packet = DatagramPacket(receiveBuffer, receiveBuffer.size)
                    udpAudioSocket?.receive(packet)
                    if (packet.length > 0) {
                        audioTrack?.write(packet.data, 0, packet.length)
                    }
                } catch (e: Exception) {
                    if (!isCallActive.get()) break
                    Log.e(TAG, "Error receiving audio packet", e)
                }
            }
        }
    }

    private fun launchRecorderThread(targetIp: String) {
        scope.launch(Dispatchers.IO) {
            val minBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG_IN, AUDIO_FORMAT)
            val bufferSize = Math.max(minBufferSize, 2048)

            try {
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    SAMPLE_RATE,
                    CHANNEL_CONFIG_IN,
                    AUDIO_FORMAT,
                    bufferSize
                )
                audioRecord?.startRecording()
            } catch (e: Exception) {
                Log.e(TAG, "Error initializing AudioRecord", e)
            }

            val sendBuffer = ByteArray(1024)
            val destAddress = try {
                if (targetIp.isBlank() || targetIp == "127.0.0.1") InetAddress.getLoopbackAddress()
                else InetAddress.getByName(targetIp)
            } catch (e: Exception) {
                InetAddress.getLoopbackAddress()
            }

            while (isCallActive.get()) {
                try {
                    val readBytes = audioRecord?.read(sendBuffer, 0, sendBuffer.size) ?: -1
                    if (readBytes > 0) {
                        if (_callInfo.value.isMuted) {
                            sendBuffer.fill(0)
                        }
                        val packet = DatagramPacket(sendBuffer, readBytes, destAddress, AUDIO_PORT)
                        udpAudioSocket?.send(packet)
                    }
                } catch (e: Exception) {
                    if (!isCallActive.get()) break
                    Log.e(TAG, "Error recording audio", e)
                }
            }
        }
    }

    private fun launchVideoReceiverThread() {
        scope.launch(Dispatchers.IO) {
            val buffer = ByteArray(65535)
            while (isCallActive.get()) {
                try {
                    val packet = DatagramPacket(buffer, buffer.size)
                    udpVideoSocket?.receive(packet)
                    if (packet.length > 0) {
                        val bitmap = BitmapFactory.decodeByteArray(packet.data, 0, packet.length)
                        if (bitmap != null) {
                            _remoteVideoFrame.value = bitmap
                        }
                    }
                } catch (e: Exception) {
                    if (!isCallActive.get()) break
                    Log.e(TAG, "Error receiving UDP video frame", e)
                }
            }
        }
    }

    private fun stopCallStreams() {
        isCallActive.set(false)
        durationTimerJob?.cancel()
        _remoteVideoFrame.value = null

        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping AudioRecord", e)
        }

        try {
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping AudioTrack", e)
        }

        try {
            udpAudioSocket?.close()
            udpAudioSocket = null
        } catch (e: Exception) {
            Log.e(TAG, "Error closing UDP audio socket", e)
        }

        try {
            udpVideoSocket?.close()
            udpVideoSocket = null
        } catch (e: Exception) {
            Log.e(TAG, "Error closing UDP video socket", e)
        }

        try {
            audioManager.mode = AudioManager.MODE_NORMAL
            audioManager.isSpeakerphoneOn = false
        } catch (e: Exception) {
            Log.e(TAG, "Error resetting audio manager", e)
        }
    }

    private fun playRingbackTone() {
        scope.launch {
            try {
                stopTone()
                toneGenerator = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 80)
                toneGenerator?.startTone(ToneGenerator.TONE_SUP_RINGTONE, 3000)
            } catch (e: Exception) {
                Log.e(TAG, "Error playing ringback tone", e)
            }
        }
    }

    private fun playIncomingRingtone() {
        scope.launch {
            try {
                stopTone()
                toneGenerator = ToneGenerator(AudioManager.STREAM_RING, 90)
                toneGenerator?.startTone(ToneGenerator.TONE_SUP_RINGTONE, 3000)
            } catch (e: Exception) {
                Log.e(TAG, "Error playing incoming ringtone", e)
            }
        }
    }

    private fun playHangupTone() {
        scope.launch {
            try {
                val hangupTone = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 80)
                hangupTone.startTone(ToneGenerator.TONE_PROP_PROMPT, 300)
                kotlinx.coroutines.delay(400)
                hangupTone.release()
            } catch (e: Exception) {
                Log.e(TAG, "Error playing hangup tone", e)
            }
        }
    }

    private fun stopTone() {
        try {
            toneGenerator?.stopTone()
            toneGenerator?.release()
            toneGenerator = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping tone generator", e)
        }
    }

    private fun resetCallState() {
        _callInfo.value = CallInfo()
        _remoteVideoFrame.value = null
    }
}
