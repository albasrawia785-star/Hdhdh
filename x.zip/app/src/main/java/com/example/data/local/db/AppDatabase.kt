package com.example.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.db.dao.ChatRequestDao
import com.example.data.local.db.dao.ConversationDao
import com.example.data.local.db.dao.ErrorLogDao
import com.example.data.local.db.dao.MessageDao
import com.example.data.local.db.entity.ChatRequestEntity
import com.example.data.local.db.entity.ConversationEntity
import com.example.data.local.db.entity.ErrorLogEntity
import com.example.data.local.db.entity.MessageEntity

@Database(
    entities = [
        ConversationEntity::class,
        MessageEntity::class,
        ChatRequestEntity::class,
        ErrorLogEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun chatRequestDao(): ChatRequestDao
    abstract fun errorLogDao(): ErrorLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "lan_messenger_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
