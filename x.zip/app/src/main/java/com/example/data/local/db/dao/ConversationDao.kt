package com.example.data.local.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.db.entity.ConversationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY lastMessageTimestamp DESC")
    fun getAllConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE targetDeviceId = :deviceId LIMIT 1")
    suspend fun getConversationByDeviceId(deviceId: String): ConversationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateConversation(conversation: ConversationEntity)

    @Query("UPDATE conversations SET lastMessage = :lastMessage, lastMessageTimestamp = :timestamp WHERE targetDeviceId = :targetDeviceId")
    suspend fun updateLastMessage(targetDeviceId: String, lastMessage: String, timestamp: Long)

    @Query("UPDATE conversations SET unreadCount = 0 WHERE targetDeviceId = :targetDeviceId")
    suspend fun clearUnreadCount(targetDeviceId: String)

    @Query("UPDATE conversations SET unreadCount = unreadCount + 1 WHERE targetDeviceId = :targetDeviceId")
    suspend fun incrementUnreadCount(targetDeviceId: String)

    @Query("UPDATE conversations SET isAccepted = :isAccepted WHERE targetDeviceId = :targetDeviceId")
    suspend fun updateAcceptedStatus(targetDeviceId: String, isAccepted: Boolean)

    @Query("UPDATE conversations SET targetIpAddress = :ip WHERE targetDeviceId = :targetDeviceId")
    suspend fun updateTargetIp(targetDeviceId: String, ip: String)

    @Query("SELECT targetIpAddress FROM conversations WHERE targetIpAddress IS NOT NULL AND targetIpAddress != ''")
    suspend fun getAllKnownTargetIps(): List<String>

    @Query("DELETE FROM conversations")
    suspend fun deleteAllConversations()

    @Query("DELETE FROM conversations WHERE targetDeviceId = :targetDeviceId")
    suspend fun deleteConversation(targetDeviceId: String)
}
