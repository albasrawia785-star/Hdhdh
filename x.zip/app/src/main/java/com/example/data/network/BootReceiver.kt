package com.example.data.network

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

class BootReceiver : BroadcastReceiver() {
    companion object {
        private const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        Log.i(TAG, "BootReceiver received action: $action")

        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == "com.htc.intent.action.QUICKBOOT_POWERON" ||
            action == "android.net.conn.CONNECTIVITY_CHANGE" ||
            action == "android.net.wifi.STATE_CHANGE" ||
            action == "android.net.wifi.WIFI_STATE_CHANGED"
        ) {
            try {
                Log.i(TAG, "Starting P2P Foreground Service from BootReceiver...")
                P2PForegroundService.startService(context.applicationContext)
            } catch (e: Throwable) {
                Log.e(TAG, "Failed to start P2P Foreground Service from BootReceiver", e)
            }
        }
    }
}
