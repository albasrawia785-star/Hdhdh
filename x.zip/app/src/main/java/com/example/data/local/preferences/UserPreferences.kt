package com.example.data.local.preferences

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID

class UserPreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("lan_messenger_prefs", Context.MODE_PRIVATE)

    private val _deviceName = MutableStateFlow(getDeviceName())
    val deviceName: StateFlow<String> = _deviceName

    private val _connectionMode = MutableStateFlow(getConnectionMode())
    val connectionMode: StateFlow<String> = _connectionMode

    private val _avatarPath = MutableStateFlow(getUserAvatarPath())
    val avatarPath: StateFlow<String> = _avatarPath

    val deviceId: String
        get() {
            var id = prefs.getString("device_id", null)
            if (id == null) {
                id = "DEV-" + UUID.randomUUID().toString().take(8)
                prefs.edit().putString("device_id", id).apply()
            }
            return id
        }

    val appCipherKey: String
        get() {
            var key = prefs.getString("app_cipher_key", null)
            if (key == null) {
                key = "WASEL_P2P_KEY_" + UUID.randomUUID().toString().replace("-", "").take(12)
                prefs.edit().putString("app_cipher_key", key).apply()
            }
            return key
        }

    fun getDeviceName(): String {
        return prefs.getString("device_name", null) ?: getFallbackDeviceName()
    }

    fun setDeviceName(newName: String) {
        val trimmed = newName.trim().ifEmpty { getFallbackDeviceName() }
        prefs.edit().putString("device_name", trimmed).apply()
        _deviceName.value = trimmed
    }

    fun getUserAvatarPath(): String {
        return prefs.getString("user_avatar_path", "") ?: ""
    }

    fun setUserAvatarPath(path: String) {
        prefs.edit().putString("user_avatar_path", path).apply()
        _avatarPath.value = path
    }

    fun getUserAvatarBase64(): String {
        val path = getUserAvatarPath()
        if (path.isBlank()) return ""
        return try {
            val file = java.io.File(path)
            if (!file.exists()) return ""
            val bitmap = android.graphics.BitmapFactory.decodeFile(file.absolutePath) ?: return ""
            val scaled = android.graphics.Bitmap.createScaledBitmap(bitmap, 128, 128, true)
            val baos = java.io.ByteArrayOutputStream()
            scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, 75, baos)
            android.util.Base64.encodeToString(baos.toByteArray(), android.util.Base64.NO_WRAP)
        } catch (e: Exception) {
            ""
        }
    }

    fun getConnectionMode(): String {
        return prefs.getString("connection_mode", MODE_HOTSPOT) ?: MODE_HOTSPOT
    }

    fun setConnectionMode(mode: String) {
        prefs.edit().putString("connection_mode", mode).apply()
        _connectionMode.value = mode
    }

    private fun getFallbackDeviceName(): String {
        val manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = Build.MODEL
        return if (model.startsWith(manufacturer, ignoreCase = true)) {
            model
        } else {
            "$manufacturer $model"
        }
    }

    companion object {
        const val MODE_ROUTER = "ROUTER"
        const val MODE_HOTSPOT = "HOTSPOT"
        const val WASEL_APP_SIGNATURE = "WASEL_OFFLINE_P2P_KEY_2026"
    }
}
