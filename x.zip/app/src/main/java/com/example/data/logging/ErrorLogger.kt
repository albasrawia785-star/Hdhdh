package com.example.data.logging

import android.content.Context
import android.os.Build
import android.util.Log
import com.example.data.local.db.AppDatabase
import com.example.data.local.db.entity.ErrorLogEntity
import com.example.data.local.preferences.UserPreferences
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ErrorLogger private constructor(private val context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val userPrefs = UserPreferences(context)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val coroutineExceptionHandler = CoroutineExceptionHandler { _, throwable ->
        Log.e(TAG, "Unhandled Coroutine Exception", throwable)
        logInternal(
            throwable = throwable,
            message = "Unhandled Coroutine Exception",
            screenName = "Coroutine",
            errorType = "CRITICAL"
        )
    }

    companion object {
        private const val TAG = "ErrorLogger"

        @Volatile
        private var INSTANCE: ErrorLogger? = null

        fun getInstance(context: Context): ErrorLogger {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ErrorLogger(context.applicationContext).also { INSTANCE = it }
            }
        }

        fun log(
            context: Context,
            throwable: Throwable? = null,
            message: String = "",
            screenName: String = "",
            errorType: String = "CRITICAL", // CRITICAL, WARNING, INFO
            connectionStatus: String = "Active",
            ipAddress: String = "",
            isHost: Boolean = false
        ) {
            runCatching {
                getInstance(context).logInternal(
                    throwable = throwable,
                    message = message,
                    screenName = screenName,
                    errorType = errorType,
                    connectionStatus = connectionStatus,
                    ipAddress = ipAddress,
                    isHost = isHost
                )
            }
        }
    }

    fun initUncaughtExceptionHandler() {
        runCatching {
            val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
                Log.e(TAG, "Uncaught Exception in thread ${thread.name}", throwable)
                logInternal(
                    throwable = throwable,
                    message = "Uncaught Exception in thread: ${thread.name}",
                    screenName = "Global",
                    errorType = "CRITICAL"
                )
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
    }

    fun logInternal(
        throwable: Throwable? = null,
        message: String = "",
        screenName: String = "",
        errorType: String = "CRITICAL",
        connectionStatus: String = "Active",
        ipAddress: String = "",
        isHost: Boolean = false
    ) {
        scope.launch {
            try {
                val stackTrace = throwable?.let {
                    val sw = StringWriter()
                    it.printStackTrace(PrintWriter(sw))
                    sw.toString()
                } ?: ""

                var fileName = ""
                var functionName = ""
                var lineNumber = -1

                throwable?.stackTrace?.firstOrNull()?.let { element ->
                    fileName = element.fileName ?: ""
                    functionName = element.methodName ?: ""
                    lineNumber = element.lineNumber
                } ?: run {
                    Thread.currentThread().stackTrace.getOrNull(4)?.let { element ->
                        fileName = element.fileName ?: ""
                        functionName = element.methodName ?: ""
                        lineNumber = element.lineNumber
                    }
                }

                val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                val dateTimeStr = dateFormat.format(Date())

                val logEntity = ErrorLogEntity(
                    timestamp = System.currentTimeMillis(),
                    dateTimeFormatted = dateTimeStr,
                    screenName = screenName.ifBlank { "System" },
                    fileName = fileName,
                    functionName = functionName,
                    lineNumber = lineNumber,
                    errorType = errorType,
                    errorMessage = message.ifBlank { throwable?.localizedMessage ?: "Unknown Error" },
                    stackTrace = stackTrace,
                    appVersion = "1.0.0",
                    androidVersion = "Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})",
                    deviceName = userPrefs.getDeviceName(),
                    deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}",
                    ipAddress = ipAddress,
                    connectionStatus = connectionStatus,
                    isHost = isHost
                )

                db.errorLogDao().insertLog(logEntity)
                Log.i(TAG, "Saved error log: [$errorType] $message (${logEntity.errorMessage})")
            } catch (e: Throwable) {
                Log.e(TAG, "Error saving log entity", e)
            }
        }
    }
}
