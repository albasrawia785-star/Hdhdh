package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.presentation.chat.ChatScreen
import com.example.presentation.chat.ChatViewModel
import com.example.presentation.home.HomeScreen
import com.example.presentation.home.HomeViewModel
import com.example.presentation.navigation.Screen
import com.example.presentation.settings.SettingsScreen
import com.example.presentation.settings.SettingsViewModel
import com.example.ui.theme.MyApplicationTheme
import java.net.URLDecoder

import com.example.data.logging.ErrorLogger
import com.example.data.local.preferences.UserPreferences
import com.example.presentation.connection.SelectConnectionScreen
import com.example.presentation.connection.SelectConnectionViewModel
import com.example.presentation.settings.ErrorLogScreen
import com.example.presentation.settings.ErrorLogViewModel

class MainActivity : ComponentActivity() {

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        ErrorLogger.getInstance(applicationContext).initUncaughtExceptionHandler()

        requestRequiredPermissions()

        try {
            com.example.data.network.P2PForegroundService.startService(applicationContext)
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Error starting foreground service", e)
        }

        setContent {
            MyApplicationTheme {
                MainAppNavHost()
            }
        }
    }

    private fun requestRequiredPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
            permissions.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
            permissions.add(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

        val needed = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }
}

@Composable
fun MainAppNavHost() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Screen.Home.route,
        modifier = Modifier.fillMaxSize()
    ) {
        composable(Screen.SelectConnection.route) {
            val selectConnectionViewModel: SelectConnectionViewModel = viewModel()
            SelectConnectionScreen(
                viewModel = selectConnectionViewModel,
                onConnectionSelected = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.SelectConnection.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Home.route) {
            val homeViewModel: HomeViewModel = viewModel()
            HomeScreen(
                viewModel = homeViewModel,
                onNavigateToChat = { deviceId, deviceName, deviceIp ->
                    if (navController.currentDestination?.route?.startsWith("chat") != true) {
                        val route = Screen.Chat.createRoute(deviceId, deviceName, deviceIp)
                        android.util.Log.i("MainActivity", "Navigation Started: $route")
                        try {
                            navController.navigate(route) {
                                launchSingleTop = true
                            }
                            android.util.Log.i("MainActivity", "Navigation Completed")
                        } catch (e: Exception) {
                            android.util.Log.e("MainActivity", "Error during navigation to chat", e)
                        }
                    }
                },
                onNavigateToSettings = {
                    if (navController.currentDestination?.route != Screen.Settings.route) {
                        navController.navigate(Screen.Settings.route) {
                            launchSingleTop = true
                        }
                    }
                }
            )
        }

        composable(
            route = Screen.Chat.route,
            arguments = listOf(
                navArgument("deviceId") { type = NavType.StringType },
                navArgument("deviceName") { type = NavType.StringType },
                navArgument("deviceIp") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val deviceId = backStackEntry.arguments?.getString("deviceId") ?: ""
            val encodedName = backStackEntry.arguments?.getString("deviceName") ?: ""
            val encodedIp = backStackEntry.arguments?.getString("deviceIp") ?: ""

            val deviceName = try { android.net.Uri.decode(encodedName) } catch (e: Exception) { encodedName }
            val deviceIp = try { android.net.Uri.decode(encodedIp) } catch (e: Exception) { encodedIp }

            val chatViewModel: ChatViewModel = viewModel()

            ChatScreen(
                targetDeviceId = deviceId,
                targetDeviceName = deviceName,
                targetIp = deviceIp,
                viewModel = chatViewModel,
                onBackClick = {
                    if (navController.currentDestination?.route?.startsWith("chat") == true) {
                        navController.popBackStack()
                    }
                }
            )
        }

        composable(Screen.Settings.route) {
            val settingsViewModel: SettingsViewModel = viewModel()
            SettingsScreen(
                viewModel = settingsViewModel,
                onBackClick = {
                    if (navController.currentDestination?.route == Screen.Settings.route) {
                        navController.popBackStack()
                    }
                },
                onNavigateToErrorLogs = {
                    if (navController.currentDestination?.route != Screen.ErrorLogs.route) {
                        try {
                            navController.navigate(Screen.ErrorLogs.route) {
                                launchSingleTop = true
                            }
                        } catch (e: Exception) {
                            android.util.Log.e("MainActivity", "Error navigating to Error Logs", e)
                        }
                    }
                }
            )
        }

        composable(Screen.ErrorLogs.route) {
            val errorLogViewModel: ErrorLogViewModel = viewModel()
            ErrorLogScreen(
                viewModel = errorLogViewModel,
                onBackClick = {
                    if (navController.currentDestination?.route == Screen.ErrorLogs.route) {
                        navController.popBackStack()
                    }
                }
            )
        }
    }
}

