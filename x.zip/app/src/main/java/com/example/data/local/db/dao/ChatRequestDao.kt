package com.example.data.local.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.db.entity.ChatRequestEntity
import com.example.domain.model.RequestStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatRequestDao {
    @Query("SELECT * FROM chat_requests ORDER BY timestamp DESC")
    fun getAllRequests(): Flow<List<ChatRequestEntity>>

    @Query("SELECT * FROM chat_requests WHERE status = 'PENDING' ORDER BY timestamp DESC")
    fun getPendingRequests(): Flow<List<ChatRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateRequest(request: ChatRequestEntity)

    @Query("UPDATE chat_requests SET status = :status WHERE requestId = :requestId")
    suspend fun updateRequestStatus(requestId: String, status: RequestStatus)

    @Query("DELETE FROM chat_requests")
    suspend fun deleteAllRequests()
}
