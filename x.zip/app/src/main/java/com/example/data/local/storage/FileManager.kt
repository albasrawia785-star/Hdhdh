package com.example.data.local.storage

import android.content.ContentValues
import android.content.Context
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

class FileManager(private val context: Context) {

    private var mediaRecorder: MediaRecorder? = null
    private var currentAudioFile: File? = null

    companion object {
        private const val TAG = "FileManager"
    }

    init {
        try {
            val mediaDir = File(context.filesDir, "media")
            if (!mediaDir.exists()) {
                mediaDir.mkdirs()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing media directory", e)
        }
    }

    fun saveBytesToInternalStorage(fileName: String, bytes: ByteArray): String? {
        return try {
            val mediaDir = File(context.filesDir, "media")
            if (!mediaDir.exists()) mediaDir.mkdirs()
            val destFile = File(mediaDir, "${System.currentTimeMillis()}_$fileName")
            FileOutputStream(destFile).use { fos ->
                fos.write(bytes)
            }
            destFile.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Error saving bytes to internal storage", e)
            null
        }
    }

    fun appendChunkToTempStorage(messageId: String, fileName: String, bytes: ByteArray, isLastChunk: Boolean): String? {
        return try {
            val mediaDir = File(context.filesDir, "media")
            if (!mediaDir.exists()) mediaDir.mkdirs()
            val tempFile = File(mediaDir, "temp_$messageId.part")
            FileOutputStream(tempFile, true).use { fos ->
                fos.write(bytes)
            }
            if (isLastChunk) {
                val safeFileName = if (fileName.isNotBlank()) fileName else "file_${System.currentTimeMillis()}"
                val finalFile = File(mediaDir, "${System.currentTimeMillis()}_$safeFileName")
                if (tempFile.renameTo(finalFile)) {
                    finalFile.absolutePath
                } else {
                    tempFile.inputStream().use { input ->
                        finalFile.outputStream().use { output ->
                            input.copyTo(output)
                        }
                    }
                    tempFile.delete()
                    finalFile.absolutePath
                }
            } else {
                tempFile.absolutePath
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error appending chunk to storage", e)
            null
        }
    }

    fun copyUriToInternalStorage(uri: Uri, fileName: String): String? {
        return try {
            val mediaDir = File(context.filesDir, "media")
            if (!mediaDir.exists()) mediaDir.mkdirs()
            val destFile = File(mediaDir, "${System.currentTimeMillis()}_$fileName")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }
            destFile.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Error copying URI to internal storage", e)
            null
        }
    }

    fun exportToPublicDownloads(sourcePath: String, displayName: String): Boolean {
        return try {
            val sourceFile = File(sourcePath)
            if (!sourceFile.exists()) return false

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, displayName)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return false

                context.contentResolver.openOutputStream(uri)?.use { output ->
                    FileInputStream(sourceFile).use { input ->
                        input.copyTo(output)
                    }
                }
                true
            } else {
                @Suppress("DEPRECATION")
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val destFile = File(downloadsDir, displayName)
                FileInputStream(sourceFile).use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                }
                true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error exporting file to public downloads", e)
            false
        }
    }

    fun clearCache(): Int {
        var count = 0
        try {
            val mediaDir = File(context.filesDir, "media")
            if (mediaDir.exists()) {
                mediaDir.listFiles()?.forEach { file ->
                    if (file.delete()) count++
                }
            }
            context.cacheDir.listFiles()?.forEach { file ->
                if (file.delete()) count++
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error clearing cache", e)
        }
        return count
    }

    fun startAudioRecording(): File? {
        return try {
            val mediaDir = File(context.filesDir, "media")
            if (!mediaDir.exists()) mediaDir.mkdirs()
            val audioFile = File(mediaDir, "AUDIO_${UUID.randomUUID()}.m4a")
            currentAudioFile = audioFile

            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(audioFile.absolutePath)
                prepare()
                start()
            }
            mediaRecorder = recorder
            audioFile
        } catch (e: Exception) {
            Log.e(TAG, "Error starting audio recording", e)
            null
        }
    }

    fun stopAudioRecording(): File? {
        return try {
            mediaRecorder?.apply {
                try { stop() } catch (e: Exception) { Log.e(TAG, "Error stopping recorder", e) }
                release()
            }
            mediaRecorder = null
            currentAudioFile
        } catch (e: Exception) {
            Log.e(TAG, "Error in stopAudioRecording", e)
            mediaRecorder = null
            null
        }
    }
}
