package com.example.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.ChatRequest
import com.example.domain.model.RequestStatus

@Entity(tableName = "chat_requests")
data class ChatRequestEntity(
    @PrimaryKey val requestId: String,
    val senderDeviceId: String,
    val senderName: String,
    val senderIp: String,
    val timestamp: Long,
    val status: RequestStatus
) {
    fun toDomain(): ChatRequest {
        return ChatRequest(
            requestId = requestId,
            senderDeviceId = senderDeviceId,
            senderName = senderName,
            senderIp = senderIp,
            timestamp = timestamp,
            status = status
        )
    }

    companion object {
        fun fromDomain(domain: ChatRequest): ChatRequestEntity {
            return ChatRequestEntity(
                requestId = domain.requestId,
                senderDeviceId = domain.senderDeviceId,
                senderName = domain.senderName,
                senderIp = domain.senderIp,
                timestamp = domain.timestamp,
                status = domain.status
            )
        }
    }
}
