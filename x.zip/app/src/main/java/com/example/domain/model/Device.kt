package com.example.domain.model

/**
 * Represents a device discovered on the local network (LAN / Hotspot).
 */
data class DiscoveredDevice(
    val deviceId: String,
    val deviceName: String,
    val ipAddress: String,
    val port: Int = 8889,
    val lastSeenTimestamp: Long = System.currentTimeMillis(),
    val isOnline: Boolean = true,
    val avatarBase64: String = ""
)
