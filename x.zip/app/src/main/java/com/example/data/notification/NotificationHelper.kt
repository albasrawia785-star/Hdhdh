package com.example.data.notification

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity

class NotificationHelper(private val context: Context) {

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    companion object {
        private const val CHANNEL_REQUESTS = "channel_chat_requests"
        private const val CHANNEL_MESSAGES = "channel_new_messages"
        private const val REQ_ID = 1001
        private const val MSG_ID = 2001
        private const val TAG = "NotificationHelper"
    }

    init {
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val reqChannel = NotificationChannel(
                    CHANNEL_REQUESTS,
                    "طلبات المراسلة",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "إشعارات عند تلقي طلب مراسلة جديد من جهاز آخر"
                    enableVibration(true)
                    enableLights(true)
                }

                val msgChannel = NotificationChannel(
                    CHANNEL_MESSAGES,
                    "الرسائل الجديدة",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "إشعارات عند وصول رسالة جديدة من المحادثات"
                    enableVibration(true)
                    enableLights(true)
                }

                notificationManager.createNotificationChannel(reqChannel)
                notificationManager.createNotificationChannel(msgChannel)
            } catch (e: Exception) {
                Log.e(TAG, "Error creating notification channels", e)
            }
        }
    }

    fun showChatRequestNotification(senderName: String) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    return
                }
            }

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                REQ_ID,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = NotificationCompat.Builder(context, CHANNEL_REQUESTS)
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle("طلب محادثة جديد")
                .setContentText("يريد جهاز $senderName بدء محادثة معك")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_SOCIAL)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            val notificationId = REQ_ID + senderName.hashCode().let { if (it < 0) -it else it } % 1000
            notificationManager.notify(notificationId, builder.build())
        } catch (e: Throwable) {
            Log.e(TAG, "Error showing chat request notification", e)
        }
    }

    fun showNewMessageNotification(senderName: String, messageText: String) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    return
                }
            }

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                MSG_ID,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = NotificationCompat.Builder(context, CHANNEL_MESSAGES)
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle(senderName)
                .setContentText(messageText)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            val notificationId = MSG_ID + senderName.hashCode().let { if (it < 0) -it else it } % 1000
            notificationManager.notify(notificationId, builder.build())
        } catch (e: Throwable) {
            Log.e(TAG, "Error showing new message notification", e)
        }
    }
}
