package com.example.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.Message
import com.example.domain.model.MessageStatus
import com.example.domain.model.MessageType

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val senderDeviceId: String,
    val senderName: String,
    val isFromMe: Boolean,
    val type: MessageType,
    val textContent: String,
    val filePath: String?,
    val fileName: String?,
    val fileSize: Long,
    val audioDurationMs: Long,
    val timestamp: Long,
    val status: MessageStatus
) {
    fun toDomain(): Message {
        return Message(
            id = id,
            conversationId = conversationId,
            senderDeviceId = senderDeviceId,
            senderName = senderName,
            isFromMe = isFromMe,
            type = type,
            textContent = textContent,
            filePath = filePath,
            fileName = fileName,
            fileSize = fileSize,
            audioDurationMs = audioDurationMs,
            timestamp = timestamp,
            status = status
        )
    }

    companion object {
        fun fromDomain(domain: Message): MessageEntity {
            return MessageEntity(
                id = domain.id,
                conversationId = domain.conversationId,
                senderDeviceId = domain.senderDeviceId,
                senderName = domain.senderName,
                isFromMe = domain.isFromMe,
                type = domain.type,
                textContent = domain.textContent,
                filePath = domain.filePath,
                fileName = domain.fileName,
                fileSize = domain.fileSize,
                audioDurationMs = domain.audioDurationMs,
                timestamp = domain.timestamp,
                status = domain.status
            )
        }
    }
}
