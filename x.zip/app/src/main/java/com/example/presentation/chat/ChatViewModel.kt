package com.example.presentation.chat

import android.app.Application
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.db.AppDatabase
import com.example.data.local.preferences.UserPreferences
import com.example.data.local.storage.FileManager
import com.example.data.logging.ErrorLogger
import com.example.data.network.CallInfo
import com.example.data.network.P2PNetworkManager
import com.example.data.network.VoiceCallManager
import com.example.data.notification.NotificationHelper
import com.example.domain.model.Message
import com.example.domain.model.MessageType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import java.io.File

data class AudioPlaybackState(
    val playingMessageId: String? = null,
    val isPlaying: Boolean = false,
    val currentPositionMs: Int = 0,
    val totalDurationMs: Int = 0
)

data class ActiveCallState(
    val isActive: Boolean = false,
    val isConnected: Boolean = false,
    val isMuted: Boolean = false,
    val durationSeconds: Int = 0,
    val targetName: String = "",
    val targetIp: String = ""
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val userPrefs = UserPreferences(application)
    val fileManager = FileManager(application)
    private val notificationHelper = NotificationHelper(application)

    val p2pManager = P2PNetworkManager.getInstance(application)

    private var targetDeviceId: String = ""
    private var targetDeviceName: String = ""
    private var targetIpAddress: String = ""
    private var isInitialized = false

    private val _isRecordingAudio = MutableStateFlow(false)
    val isRecordingAudio: StateFlow<Boolean> = _isRecordingAudio.asStateFlow()

    private val _recordingDurationSeconds = MutableStateFlow(0)
    val recordingDurationSeconds: StateFlow<Int> = _recordingDurationSeconds.asStateFlow()

    private var recordingTimerJob: Job? = null

    private var mediaPlayer: MediaPlayer? = null
    private val _audioPlaybackState = MutableStateFlow(AudioPlaybackState())
    val audioPlaybackState: StateFlow<AudioPlaybackState> = _audioPlaybackState.asStateFlow()

    private val _messages = MutableStateFlow<List<Message>>(emptyList())
    val messages: StateFlow<List<Message>> = _messages.asStateFlow()

    private val _isPeerOnline = MutableStateFlow(true)
    val isPeerOnline: StateFlow<Boolean> = _isPeerOnline.asStateFlow()

    private val _isPeerTyping = MutableStateFlow(false)
    val isPeerTyping: StateFlow<Boolean> = _isPeerTyping.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    companion object {
        private const val TAG = "ChatViewModel"
    }

    fun init(deviceId: String, deviceName: String, deviceIp: String) {
        if (deviceId.isBlank()) {
            Log.e(TAG, "Cannot init ChatViewModel with blank deviceId")
            return
        }
        if (isInitialized && targetDeviceId == deviceId) return

        this.targetDeviceId = deviceId
        this.targetDeviceName = deviceName
        this.targetIpAddress = deviceIp
        this.isInitialized = true

        p2pManager.setActiveChatDeviceId(deviceId)
        p2pManager.startEngine()

        viewModelScope.launch(Dispatchers.IO) {
            try {
                p2pManager.sendReadReceipt(targetDeviceId, targetIpAddress)
            } catch (e: Exception) {
                Log.e(TAG, "Error sending read receipt", e)
            }
        }

        viewModelScope.launch(Dispatchers.IO) {
            db.messageDao().getMessagesForConversation(targetDeviceId)
                .catch { e -> Log.e(TAG, "Error collecting messages for $targetDeviceId", e) }
                .collect { list ->
                    val sortedList = list.map { it.toDomain() }.sortedBy { it.timestamp }
                    _messages.value = sortedList
                    val hasUnreadIncoming = list.any { !it.isFromMe && it.status != com.example.domain.model.MessageStatus.READ }
                    if (hasUnreadIncoming) {
                        p2pManager.sendReadReceipt(targetDeviceId, targetIpAddress)
                    }
                }
        }

        viewModelScope.launch {
            p2pManager.discoveredDevices.collect { devices ->
                val device = devices.find { it.deviceId == targetDeviceId }
                if (device != null) {
                    if (device.ipAddress.isNotBlank()) {
                        targetIpAddress = device.ipAddress
                    }
                    _isPeerOnline.value = device.isOnline
                } else {
                    _isPeerOnline.value = false
                }
            }
        }

        viewModelScope.launch {
            p2pManager.typingStatus.collect { map ->
                _isPeerTyping.value = map[targetDeviceId] ?: false
            }
        }
    }

    fun sendTextMessage(text: String) {
        if (text.isBlank() || targetDeviceId.isBlank()) return
        try {
            p2pManager.sendTextMessage(targetDeviceId, targetIpAddress, text.trim())
        } catch (e: Exception) {
            Log.e(TAG, "Error sending text message", e)
            ErrorLogger.log(
                context = getApplication(),
                throwable = e,
                message = "Error sending text message: ${e.localizedMessage}",
                screenName = "ChatScreen",
                errorType = "WARNING",
                ipAddress = targetIpAddress
            )
            _toastMessage.value = "فشل إرسال الرسالة"
        }
    }

    fun sendImageUri(uri: Uri) {
        if (targetDeviceId.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val fileName = "IMG_${System.currentTimeMillis()}.jpg"
                val localPath = fileManager.copyUriToInternalStorage(uri, fileName)
                if (localPath != null) {
                    p2pManager.sendMediaMessage(
                        targetDeviceId = targetDeviceId,
                        targetIp = targetIpAddress,
                        type = MessageType.IMAGE,
                        file = File(localPath),
                        fileName = fileName
                    )
                } else {
                    _toastMessage.value = "تعذر نسخ الصورة"
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error sending image", e)
                _toastMessage.value = "فشل إرسال الصورة"
            }
        }
    }

    fun sendFileUri(uri: Uri, fileName: String) {
        if (targetDeviceId.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val localPath = fileManager.copyUriToInternalStorage(uri, fileName)
                if (localPath != null) {
                    p2pManager.sendMediaMessage(
                        targetDeviceId = targetDeviceId,
                        targetIp = targetIpAddress,
                        type = MessageType.FILE,
                        file = File(localPath),
                        fileName = fileName
                    )
                } else {
                    _toastMessage.value = "تعذر قراءة الملف"
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error sending file", e)
                _toastMessage.value = "فشل إرسال الملف"
            }
        }
    }

    fun startRecordingAudio() {
        try {
            val audioFile = fileManager.startAudioRecording()
            if (audioFile != null) {
                _isRecordingAudio.value = true
                _recordingDurationSeconds.value = 0
                recordingTimerJob?.cancel()
                recordingTimerJob = viewModelScope.launch {
                    while (_isRecordingAudio.value) {
                        delay(1000)
                        _recordingDurationSeconds.value += 1
                    }
                }
            } else {
                _toastMessage.value = "تعذر بدء التسجيل الصوتي"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error starting audio recording", e)
            _toastMessage.value = "حدث خطأ أثناء بدء التسجيل"
        }
    }

    fun stopAndSendAudioRecording() {
        try {
            recordingTimerJob?.cancel()
            _isRecordingAudio.value = false
            val durationMs = (_recordingDurationSeconds.value * 1000).toLong()
            val audioFile = fileManager.stopAudioRecording()

            if (audioFile != null && audioFile.exists() && audioFile.length() > 0 && targetDeviceId.isNotBlank()) {
                p2pManager.sendMediaMessage(
                    targetDeviceId = targetDeviceId,
                    targetIp = targetIpAddress,
                    type = MessageType.AUDIO,
                    file = audioFile,
                    fileName = audioFile.name,
                    audioDurationMs = durationMs
                )
            }
            _recordingDurationSeconds.value = 0
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping audio recording", e)
            _toastMessage.value = "فشل إرسال التسجيل الصوتي"
            _recordingDurationSeconds.value = 0
        }
    }

    fun cancelAudioRecording() {
        try {
            recordingTimerJob?.cancel()
            _isRecordingAudio.value = false
            fileManager.stopAudioRecording()
            _recordingDurationSeconds.value = 0
        } catch (e: Exception) {
            Log.e(TAG, "Error cancelling audio recording", e)
        }
    }

    fun playAudio(messageId: String, filePath: String) {
        val currentState = _audioPlaybackState.value
        if (currentState.playingMessageId == messageId && currentState.isPlaying) {
            try {
                mediaPlayer?.pause()
                _audioPlaybackState.value = currentState.copy(isPlaying = false)
            } catch (e: Exception) {
                Log.e(TAG, "Error pausing player", e)
            }
            return
        }

        try {
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing old player", e)
        }

        try {
            val file = File(filePath)
            if (!file.exists()) {
                _toastMessage.value = "الملف الصوتي غير موجود"
                return
            }

            val player = MediaPlayer().apply {
                setDataSource(filePath)
                prepare()
                start()
            }
            mediaPlayer = player

            _audioPlaybackState.value = AudioPlaybackState(
                playingMessageId = messageId,
                isPlaying = true,
                totalDurationMs = player.duration
            )

            player.setOnCompletionListener {
                _audioPlaybackState.value = AudioPlaybackState()
            }

            viewModelScope.launch {
                try {
                    while (player.isPlaying) {
                        _audioPlaybackState.value = _audioPlaybackState.value.copy(
                            currentPositionMs = player.currentPosition
                        )
                        delay(300)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error updating player progress", e)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error playing audio", e)
            _toastMessage.value = "فشل تشغيل التسجيل الصوتي"
            _audioPlaybackState.value = AudioPlaybackState()
        }
    }

    fun sendTypingNotification(isTyping: Boolean) {
        if (targetIpAddress.isNotBlank()) {
            p2pManager.sendTypingStatus(targetIpAddress, isTyping)
        }
    }

    fun saveFileToPublicDownloads(filePath: String, fileName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val success = fileManager.exportToPublicDownloads(filePath, fileName)
                _toastMessage.value = if (success) "تم حفظ الملف بنجاح في مجلد التنزيلات" else "فشل حفظ الملف"
            } catch (e: Exception) {
                Log.e(TAG, "Error exporting download file", e)
                _toastMessage.value = "حدث خطأ أثناء حفظ الملف"
            }
        }
    }

    val voiceCallManager = VoiceCallManager.getInstance(application)
    val callInfo: StateFlow<CallInfo> = voiceCallManager.callInfo
    val remoteVideoFrame: StateFlow<android.graphics.Bitmap?> = voiceCallManager.remoteVideoFrame

    fun startVoiceCall() {
        if (targetDeviceId.isBlank()) return
        val resolvedIp = targetIpAddress.ifEmpty {
            p2pManager.discoveredDevices.value.find { it.deviceId == targetDeviceId }?.ipAddress ?: "127.0.0.1"
        }
        voiceCallManager.initiateCall(targetDeviceId, targetDeviceName, resolvedIp, isVideo = false)
        p2pManager.sendCallRequest(resolvedIp)
        sendTextMessage("📞 جاري طلب مكالمة صوتية مباشرة مشفرة عبر IP Network ($resolvedIp)...")
    }

    fun startVideoCall() {
        if (targetDeviceId.isBlank()) return
        val resolvedIp = targetIpAddress.ifEmpty {
            p2pManager.discoveredDevices.value.find { it.deviceId == targetDeviceId }?.ipAddress ?: "127.0.0.1"
        }
        voiceCallManager.initiateCall(targetDeviceId, targetDeviceName, resolvedIp, isVideo = true)
        p2pManager.sendVideoCallRequest(resolvedIp)
        sendTextMessage("📹 جاري طلب مكالمة فيديو محلية مباشرة عبر IP Network ($resolvedIp)...")
    }

    fun acceptCall() {
        val currentCall = callInfo.value
        voiceCallManager.acceptIncomingCall()
        p2pManager.sendCallAccept(currentCall.targetIp)
    }

    fun rejectCall() {
        val currentCall = callInfo.value
        voiceCallManager.rejectIncomingCall()
        p2pManager.sendCallReject(currentCall.targetIp)
    }

    fun toggleMuteCall() {
        voiceCallManager.toggleMute()
    }

    fun toggleSpeakerCall() {
        voiceCallManager.toggleSpeaker()
    }

    fun toggleCameraCall() {
        voiceCallManager.toggleCamera()
    }

    fun switchCameraCall() {
        voiceCallManager.switchCamera()
    }

    fun sendVideoFrame(bitmap: android.graphics.Bitmap) {
        voiceCallManager.sendVideoFrame(bitmap)
    }

    fun endVoiceCall() {
        val currentCall = callInfo.value
        val isVideo = currentCall.isVideoCall
        val duration = currentCall.durationSeconds
        voiceCallManager.endCall()
        if (currentCall.targetIp.isNotBlank()) {
            p2pManager.sendCallEnd(currentCall.targetIp)
        }
        val formatted = "%02d:%02d".format(duration / 60, duration % 60)
        val msg = if (isVideo) "📹 انتهت مكالمة الفيديو (المدة: $formatted)" else "📵 انتهت المكالمة الصوتية (المدة: $formatted)"
        sendTextMessage(msg)
    }

    fun setActiveChat() {
        if (targetDeviceId.isNotBlank()) {
            p2pManager.setActiveChatDeviceId(targetDeviceId)
        }
    }

    fun clearActiveChat() {
        if (targetDeviceId.isNotBlank() && p2pManager.getActiveChatDeviceId() == targetDeviceId) {
            p2pManager.setActiveChatDeviceId(null)
        }
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        clearActiveChat()
        try {
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing media player onCleared", e)
        }
        try {
            fileManager.stopAudioRecording()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping audio recorder onCleared", e)
        }
    }
}
