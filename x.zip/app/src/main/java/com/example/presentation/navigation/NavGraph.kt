package com.example.presentation.navigation

import android.net.Uri

sealed class Screen(val route: String) {
    object SelectConnection : Screen("select_connection")
    object Home : Screen("home")
    object Settings : Screen("settings")
    object ErrorLogs : Screen("error_logs")
    object Chat : Screen("chat/{deviceId}/{deviceName}/{deviceIp}") {
        fun createRoute(deviceId: String, deviceName: String, deviceIp: String): String {
            val safeId = Uri.encode(deviceId.ifBlank { "unknown" })
            val safeName = Uri.encode(deviceName.ifBlank { "Device" })
            val safeIp = Uri.encode(deviceIp.ifBlank { "none" })
            return "chat/$safeId/$safeName/$safeIp"
        }
    }
}
