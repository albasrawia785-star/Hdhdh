package com.example.presentation.settings

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.db.entity.ErrorLogEntity
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ErrorLogScreen(
    viewModel: ErrorLogViewModel,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {

        val logs by viewModel.logs.collectAsStateWithLifecycle()
        val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
        val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()

        var selectedLogForDetails by remember { mutableStateOf<ErrorLogEntity?>(null) }
        var showConfirmClearDialog by remember { mutableStateOf(false) }
        var exportDialogTitle by remember { mutableStateOf<String?>(null) }
        var exportDialogContent by remember { mutableStateOf<String?>(null) }

        LaunchedEffect(toastMessage) {
            toastMessage?.let {
                Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
                viewModel.clearToastMessage()
            }
        }

        Scaffold(
            containerColor = Color(0xFFF8FAFC),
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "📋 سجل الأخطاء",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = Color(0xFF1F2937)
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBackClick) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع",
                                tint = Color(0xFF1F2937)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            }
        ) { innerPadding ->

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {

                // Search Field
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.onSearchQueryChange(it) },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("🔍 بحث عن خطأ، شاشة، أو دالة...", fontSize = 14.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF64748B)) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.onSearchQueryChange("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "مسح", tint = Color(0xFF64748B))
                            }
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = Color(0xFF2563EB),
                        unfocusedBorderColor = Color(0xFFE2E8F0)
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Action Bar (Scrollable horizontally)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Clear Log Button
                    OutlinedButton(
                        onClick = { showConfirmClearDialog = true },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626))
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("حذف السجل", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    // Share Button
                    OutlinedButton(
                        onClick = { viewModel.shareLogTxt(context) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF2563EB))
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("مشاركة", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    // Export TXT Button
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                exportDialogTitle = "تصدير TXT"
                                exportDialogContent = viewModel.buildTxtRepresentation()
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF059669))
                    ) {
                        Text("📄 تصدير TXT", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    // Export JSON Button
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                exportDialogTitle = "تصدير JSON"
                                exportDialogContent = viewModel.buildJsonRepresentation()
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF7C3AED))
                    ) {
                        Text("📄 تصدير JSON", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Log List
                if (logs.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (searchQuery.isNotEmpty()) "لا توجد نتائج مطابقة للبحث" else "لا توجد أخطاء مسجلة، النظام يعمل بكفاءة!",
                                color = Color(0xFF64748B),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(logs, key = { it.id }) { log ->
                            ErrorLogCard(
                                log = log,
                                onClick = { selectedLogForDetails = log }
                            )
                        }
                    }
                }
            }

            // Confirm Clear Dialog
            if (showConfirmClearDialog) {
                AlertDialog(
                    onDismissRequest = { showConfirmClearDialog = false },
                    containerColor = Color.White,
                    title = { Text("مسح سجل الأخطاء", fontWeight = FontWeight.Bold) },
                    text = { Text("هل أنت متأكد من حذف جميع الأخطاء والتحذيرات المسجلة؟") },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.clearAllLogs()
                                showConfirmClearDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("حذف الكل", fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showConfirmClearDialog = false }) {
                            Text("إلغاء", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }

            // Details Modal Dialog
            selectedLogForDetails?.let { log ->
                ErrorLogDetailDialog(
                    log = log,
                    onDismiss = { selectedLogForDetails = null },
                    onCopy = {
                        val detailsText = """
                            التاريخ: ${log.dateTimeFormatted}
                            نوع الخطأ: ${log.errorType}
                            الشاشة: ${log.screenName}
                            الملف: ${log.fileName} (سطر ${log.lineNumber})
                            الدالة: ${log.functionName}
                            الرسالة: ${log.errorMessage}
                            الجهاز: ${log.deviceName} (${log.deviceModel})
                            Android: ${log.androidVersion}
                            عنوان IP: ${log.ipAddress}
                            StackTrace:
                            ${log.stackTrace}
                        """.trimIndent()
                        viewModel.copyToClipboard(context, detailsText)
                    }
                )
            }

            // Export Modal Dialog
            if (exportDialogTitle != null && exportDialogContent != null) {
                AlertDialog(
                    onDismissRequest = {
                        exportDialogTitle = null
                        exportDialogContent = null
                    },
                    containerColor = Color.White,
                    title = { Text(exportDialogTitle ?: "تصدير", fontWeight = FontWeight.Bold) },
                    text = {
                        Box(
                            modifier = Modifier
                                .height(300.dp)
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                                .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = exportDialogContent ?: "",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF1E293B)
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.copyToClipboard(context, exportDialogContent ?: "")
                                exportDialogTitle = null
                                exportDialogContent = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("نسخ إلى الحافظة", fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = {
                            exportDialogTitle = null
                            exportDialogContent = null
                        }) {
                            Text("إغلاق", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun ErrorLogCard(
    log: ErrorLogEntity,
    onClick: () -> Unit
) {
    val (accentColor, bgColor, typeName, icon) = when (log.errorType.uppercase()) {
        "WARNING" -> Quadruple(
            Color(0xFFD97706),
            Color(0xFFFFFBEB),
            "تحذير",
            Icons.Default.Warning
        )
        "INFO" -> Quadruple(
            Color(0xFF2563EB),
            Color(0xFFEFF6FF),
            "معلومات",
            Icons.Default.Info
        )
        else -> Quadruple(
            Color(0xFFDC2626),
            Color(0xFFFEF2F2),
            "خطأ حرج",
            Icons.Default.Error
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(bgColor)
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(typeName, color = accentColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (log.screenName.isNotBlank()) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "•  ${log.screenName}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                Text(
                    text = log.dateTimeFormatted,
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = log.errorMessage,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = Color(0xFF1E293B),
                maxLines = 2
            )

            if (log.fileName.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "${log.fileName} -> ${log.functionName}:${if (log.lineNumber > 0) log.lineNumber else ""}",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF64748B)
                )
            }
        }
    }
}

@Composable
fun ErrorLogDetailDialog(
    log: ErrorLogEntity,
    onDismiss: () -> Unit,
    onCopy: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = {
            Text("تفاصيل الخطأ [${log.errorType}]", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                DetailRow("التاريخ والوقت", log.dateTimeFormatted)
                DetailRow("الشاشة", log.screenName)
                DetailRow("اسم الملف", log.fileName)
                DetailRow("اسم الدالة", log.functionName)
                DetailRow("رقم السطر", if (log.lineNumber > 0) log.lineNumber.toString() else "غير معروف")
                DetailRow("رسالة الخطأ", log.errorMessage)
                DetailRow("اسم الجهاز", "${log.deviceName} (${log.deviceModel})")
                DetailRow("إصدار Android", log.androidVersion)
                if (log.ipAddress.isNotBlank()) {
                    DetailRow("عنوان IP", log.ipAddress)
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text("StackTrace:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF1E293B))
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = if (log.stackTrace.isNotBlank()) log.stackTrace else "لا يوجد StackTrace",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF38BDF8)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onCopy,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("نسخ التفاصيل", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إغلاق", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = "$label:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Color(0xFF64748B))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1E293B))
    }
}

data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
