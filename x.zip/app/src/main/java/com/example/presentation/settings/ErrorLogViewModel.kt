package com.example.presentation.settings

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.db.AppDatabase
import com.example.data.local.db.entity.ErrorLogEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class ErrorLogViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val errorLogDao = db.errorLogDao()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage

    val logs: StateFlow<List<ErrorLogEntity>> = errorLogDao.getAllLogs()
        .combine(_searchQuery) { allLogs, query ->
            if (query.isBlank()) {
                allLogs
            } else {
                val q = query.lowercase().trim()
                allLogs.filter { log ->
                    log.errorMessage.lowercase().contains(q) ||
                    log.screenName.lowercase().contains(q) ||
                    log.errorType.lowercase().contains(q) ||
                    log.fileName.lowercase().contains(q) ||
                    log.functionName.lowercase().contains(q) ||
                    log.stackTrace.lowercase().contains(q) ||
                    log.deviceName.lowercase().contains(q)
                }
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun clearAllLogs() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                errorLogDao.clearAllLogs()
                _toastMessage.value = "تم مسح سجل الأخطاء بنجاح"
            } catch (e: Exception) {
                _toastMessage.value = "حدث خطأ أثناء مسح السجل"
            }
        }
    }

    fun copyToClipboard(context: Context, logText: String) {
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            val clip = ClipData.newPlainText("Error Log", logText)
            clipboard?.setPrimaryClip(clip)
            _toastMessage.value = "تم نسخ النص إلى الحافظة"
        } catch (e: Exception) {
            _toastMessage.value = "فشل النسخ إلى الحافظة"
        }
    }

    suspend fun buildTxtRepresentation(): String = withContext(Dispatchers.IO) {
        val currentLogs = logs.value
        if (currentLogs.isEmpty()) return@withContext "لا توجد أخطاء مسجلة"

        val sb = StringBuilder()
        sb.append("===== سجل الأخطاء (تطبيق واصل) =====\n\n")
        currentLogs.forEachIndexed { index, log ->
            sb.append("--- [خطأ #${index + 1}] ---\n")
            sb.append("التاريخ والوقت: ${log.dateTimeFormatted}\n")
            sb.append("نوع الخطأ: ${log.errorType}\n")
            sb.append("الشاشة: ${log.screenName}\n")
            sb.append("الملف والدالة: ${log.fileName} -> ${log.functionName} (سطر ${log.lineNumber})\n")
            sb.append("رسالة الخطأ: ${log.errorMessage}\n")
            sb.append("الجهاز: ${log.deviceName} (${log.deviceModel})\n")
            sb.append("إصدار Android: ${log.androidVersion}\n")
            sb.append("عنوان IP: ${log.ipAddress}\n")
            sb.append("حالة الاتصال: ${log.connectionStatus}\n")
            sb.append("StackTrace:\n${log.stackTrace}\n")
            sb.append("-----------------------------------\n\n")
        }
        sb.toString()
    }

    suspend fun buildJsonRepresentation(): String = withContext(Dispatchers.IO) {
        val currentLogs = logs.value
        val jsonArray = JSONArray()
        currentLogs.forEach { log ->
            val jsonObject = JSONObject().apply {
                put("id", log.id)
                put("dateTime", log.dateTimeFormatted)
                put("errorType", log.errorType)
                put("screenName", log.screenName)
                put("fileName", log.fileName)
                put("functionName", log.functionName)
                put("lineNumber", log.lineNumber)
                put("errorMessage", log.errorMessage)
                put("stackTrace", log.stackTrace)
                put("appVersion", log.appVersion)
                put("androidVersion", log.androidVersion)
                put("deviceName", log.deviceName)
                put("deviceModel", log.deviceModel)
                put("ipAddress", log.ipAddress)
                put("connectionStatus", log.connectionStatus)
                put("isHost", log.isHost)
            }
            jsonArray.put(jsonObject)
        }
        jsonArray.toString(2)
    }

    fun shareLogTxt(context: Context) {
        viewModelScope.launch {
            val txtContent = buildTxtRepresentation()
            try {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "سجل الأخطاء - تطبيق واصل")
                    putExtra(Intent.EXTRA_TEXT, txtContent)
                }
                context.startActivity(Intent.createChooser(intent, "مشاركة سجل الأخطاء"))
            } catch (e: Exception) {
                _toastMessage.value = "تعذر مشاركة السجل"
            }
        }
    }

    fun clearToastMessage() {
        _toastMessage.value = null
    }
}
