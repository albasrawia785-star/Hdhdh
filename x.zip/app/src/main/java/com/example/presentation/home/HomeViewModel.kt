package com.example.presentation.home

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.db.AppDatabase
import com.example.data.local.db.entity.ChatRequestEntity
import com.example.data.local.preferences.UserPreferences
import com.example.data.local.storage.FileManager
import com.example.data.logging.ErrorLogger
import com.example.data.network.P2PNetworkManager
import com.example.data.notification.NotificationHelper
import com.example.domain.model.ChatRequest
import com.example.domain.model.Conversation
import com.example.domain.model.DiscoveredDevice
import com.example.util.NetworkUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val userPrefs = UserPreferences(application)
    private val fileManager = FileManager(application)
    private val notificationHelper = NotificationHelper(application)

    val p2pManager = P2PNetworkManager.getInstance(application)

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _isProcessingRequest = MutableStateFlow(false)
    val isProcessingRequest: StateFlow<Boolean> = _isProcessingRequest.asStateFlow()

    // Smart Network Status
    private val _wifiSsid = MutableStateFlow(NetworkUtils.getWifiSsid(application))
    val wifiSsid: StateFlow<String> = _wifiSsid.asStateFlow()

    private val _localIp = MutableStateFlow(NetworkUtils.getLocalIpAddress())
    val localIp: StateFlow<String> = _localIp.asStateFlow()

    private val _isNetworkConnected = MutableStateFlow(NetworkUtils.isWifiConnected(application) || _localIp.value.isNotEmpty())
    val isNetworkConnected: StateFlow<Boolean> = _isNetworkConnected.asStateFlow()

    val lastDiscoveryPulse: StateFlow<Long> = p2pManager.lastDiscoveryPulse

    init {
        // Force exclusive Hotspot mode
        userPrefs.setConnectionMode(UserPreferences.MODE_HOTSPOT)
        p2pManager.startEngine()
        startNetworkMonitorLoop()
    }

    private fun startNetworkMonitorLoop() {
        viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                try {
                    val app = getApplication<Application>()
                    val ip = NetworkUtils.getLocalIpAddress()
                    val wifiConnected = NetworkUtils.isWifiConnected(app) || ip.isNotEmpty()
                    val ssid = NetworkUtils.getWifiSsid(app)

                    _localIp.value = ip
                    _wifiSsid.value = ssid
                    _isNetworkConnected.value = wifiConnected

                    if (!wifiConnected || !p2pManager.isEngineActive()) {
                        p2pManager.startEngine()
                    }
                } catch (e: Exception) {
                    Log.e("HomeViewModel", "Error in network monitor loop", e)
                }
                delay(3000)
            }
        }
    }

    val myDeviceName: StateFlow<String> = userPrefs.deviceName

    val discoveredDevices: StateFlow<List<DiscoveredDevice>> = p2pManager.discoveredDevices

    val pendingRequests: StateFlow<List<ChatRequest>> = db.chatRequestDao()
        .getPendingRequests()
        .map { list -> list.map { it.toDomain() } }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val conversations: StateFlow<List<Conversation>> = combine(
        db.conversationDao().getAllConversations(),
        discoveredDevices
    ) { entities, devices ->
        entities.map { entity ->
            val matchingDevice = devices.find { it.deviceId == entity.targetDeviceId }
            val isOnline = matchingDevice?.isOnline ?: false
            val avatar = if (!matchingDevice?.avatarBase64.isNullOrBlank()) {
                matchingDevice!!.avatarBase64
            } else {
                entity.avatarBase64
            }
            val displayName = if (!matchingDevice?.deviceName.isNullOrBlank()) {
                matchingDevice!!.deviceName
            } else {
                entity.targetDeviceName
            }
            entity.toDomain(
                isOnline = isOnline,
                avatarBase64 = avatar,
                targetDeviceName = displayName
            )
        }.sortedByDescending { it.lastMessageTimestamp }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun sendChatRequest(device: DiscoveredDevice) {
        if (!device.isOnline || device.ipAddress.isBlank()) {
            _toastMessage.value = "الجهاز غير متصل حالياً"
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                p2pManager.sendChatRequest(device)
                _toastMessage.value = "تم إرسال طلب المراسلة إلى ${device.deviceName}"
            } catch (e: Exception) {
                Log.e("HomeViewModel", "Error sending chat request", e)
                _toastMessage.value = "فشل إرسال طلب المراسلة"
            }
        }
    }

    fun respondToRequest(
        request: ChatRequest,
        accept: Boolean,
        onAccepted: ((deviceId: String, deviceName: String, deviceIp: String) -> Unit)? = null
    ) {
        if (_isProcessingRequest.value) return
        _isProcessingRequest.value = true

        Log.i("HomeViewModel", "Accept Button Clicked: deviceId=${request.senderDeviceId}, accept=$accept")

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val entity = ChatRequestEntity.fromDomain(request)
                val success = p2pManager.respondToChatRequest(entity, accept)

                if (accept) {
                    if (success) {
                        val conversation = db.conversationDao().getConversationByDeviceId(request.senderDeviceId)
                        if (conversation == null) {
                            Log.e("HomeViewModel", "Conversation is null for deviceId=${request.senderDeviceId}")
                            withContext(Dispatchers.Main) {
                                _toastMessage.value = "تعذر إنشاء المحادثة"
                            }
                            return@launch
                        }

                        val targetIp = conversation.targetIpAddress.ifBlank { request.senderIp }
                        val targetName = conversation.targetDeviceName.ifBlank { request.senderName }

                        Log.i("HomeViewModel", "Navigation Started: deviceId=${request.senderDeviceId}, name=$targetName, ip=$targetIp")

                        withContext(Dispatchers.Main) {
                            onAccepted?.invoke(
                                request.senderDeviceId,
                                targetName,
                                targetIp
                            )
                        }
                    } else {
                        Log.e("HomeViewModel", "Failed to process accept chat request")
                        withContext(Dispatchers.Main) {
                            _toastMessage.value = "تعذر إنشاء المحادثة"
                        }
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        _toastMessage.value = "تم رفض طلب المراسلة"
                    }
                }
            } catch (e: Exception) {
                Log.e("HomeViewModel", "Error responding to request", e)
                ErrorLogger.log(
                    context = getApplication(),
                    throwable = e,
                    message = "Error responding to chat request: ${e.localizedMessage}",
                    screenName = "HomeScreen",
                    errorType = "CRITICAL",
                    connectionStatus = "Active"
                )
                withContext(Dispatchers.Main) {
                    _toastMessage.value = "تعذر إنشاء المحادثة"
                }
            } finally {
                _isProcessingRequest.value = false
            }
        }
    }

    fun clearToast() {
        _toastMessage.value = null
    }
}

